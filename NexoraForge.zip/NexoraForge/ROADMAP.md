# Roadmap

Критерий перехода на следующий этап: текущий собирается, тесты проходят, документация обновлена.

| Этап | Содержание | Статус |
|---|---|---|
| 0 Foundation | Gradle, Kotlin, Compose, CI, документация | сделано (не собрано в CI) |
| 1 Editor UI | Панели, тёмная тема, навигация, адаптивность | базово |
| 2 3D Viewport | GLES, камера, сетка, примитивы | базово; нет выбора касанием |
| NX 0.1 | Лексер, парсер, интерпретатор, ошибки | сделано (не собрано в CI) |
| 3 Scene System | Иерархия родитель/потомок, сохранение сцен, формат `.nxf` | следующий |
| 4 Transform Tools | Выбор касанием, гизмо Move/Rotate/Scale, Undo/Redo | |
| NX 0.2 | Семантический анализатор, `build` (типы), `ask`, модули, формализация `game` API | |
| 5+ | Mesh Lab, материалы, свет/тени, физика, анимация, аудио, UI Builder, ввод | |
| NX VM | Байткод `.nxb`, VM, затем JIT/AOT | |
| Platform | Модули NX для окон/виджетов (приложения) и HTTP/DOM через WebAssembly (сайты) | |
| Build Pipeline | Сборка APK/AAB игр из редактора | |

## Stage 1 (written, NOT yet built or run)
- Start screen: Import project / Create project / project list.
- Project file .nxf (JSON, schema 1): scripts, folders, objects. Stored in app files; import/export via system file picker.
- Several named scripts per project (create / rename / delete). Run executes the open script.
- Outliner: folders (nested), rename, move to folder, delete. Folders only group objects; they do not transform children.
