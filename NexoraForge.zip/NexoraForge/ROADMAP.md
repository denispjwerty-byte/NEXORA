# Roadmap

Критерий перехода на следующий этап: текущий собирается, тесты проходят, документация обновлена.

| Этап | Содержание | Статус |
|---|---|---|
| 0 Foundation | Gradle, Kotlin, Compose, CI, документация | сделано (не собрано в CI) |
| 1 Editor UI | Панели, тёмная тема, навигация, адаптивность | базово |
| 2 3D Viewport | GLES, камера, сетка, примитивы | базово; нет выбора касанием |
| NX 0.1 | Лексер, парсер, интерпретатор, ошибки | сделано (не собрано в CI) |
| 3 Scene System | Иерархия родитель/потомок, сохранение сцен, формат `.nxf` | следующий |
| 4 Transform Tools | Выбор касанием, гизмо Move/Rotate/Scale, Undo/Redo | |
| NX 0.2 | Семантический анализатор, `build` (типы), `ask`, модули, формализация `game` API | |
| 5+ | Mesh Lab, материалы, свет/тени, физика, анимация, аудио, UI Builder, ввод | |
| NX VM | Байткод `.nxb`, VM, затем JIT/AOT | |
| Platform | Модули NX для окон/виджетов (приложения) и HTTP/DOM через WebAssembly (сайты) | |
| Build Pipeline | Сборка APK/AAB игр из редактора | |

## Stage 1 (written, NOT yet built or run)
- Start screen: Import project / Create project / project list.
- Project file .nxf (JSON, schema 1): scripts, folders, objects. Stored in app files; import/export via system file picker.
- Several named scripts per project (create / rename / delete). Run executes the open script.
- Outliner: folders (nested), rename, move to folder, delete. Folders only group objects; they do not transform children.

## Stage 2 (written, NOT yet built or run)
- Tap an object in the viewport to select it; tap empty space to deselect (the ground plane is pickable too).
- Gizmo on the selected object: Move / Rotate / Scale buttons on the right edge of the viewport.
  Handles are in world axes. Rotation rings edit the object's X/Y/Z Euler angles directly.
- Camera orbit/zoom unchanged; touching a handle drags the object instead of the camera.
- Not done: local-space gizmo, snapping, multi-select, Undo/Redo.

## Stage 3 (written, NOT yet built or run)
- Cube button top-right: Edit / Animate. Animation tab: clips, duration, loop, timeline with keyframe diamonds, preview.
- A clip is bound to an NX action by name; `run <action>` in a script starts it. See docs/ANIMATION.md.
- Host hook `onAction` in the NX interpreter (no language change).

## Stage 4 (written, NOT yet built or run)
- Start screen: each project has a **Play** button. It opens the project and runs its active script as a game, full screen (no editor panels).
- Game screen: 3D view, last script output / errors at the bottom, **Exit** button (and system Back). Exit stops the script, restores the scene and returns to the start screen; nothing is saved.
- Camera still orbits/zooms by touch. Objects are not selectable in game mode.
- Not done: input from the player (NX has no input yet), sound, a standalone game APK.
