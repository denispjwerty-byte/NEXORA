# Animations (Nexora Forge, stage 3)

Status: written, NOT yet built or run on a device.

## Idea
An animation is a clip of keyframes (position, rotation, scale) for one or more objects.
A clip has a field **Script action**. When a script runs that action, the clip plays.
This needs no new NX syntax: it uses the existing `action` and `run`.

## Example
In the Animation tab create a clip, set "Script action" to `jump`, key the object at 0 s and 1 s.
In a script:

    action jump
        say "jumping"

    run jump

`run jump` starts the clip bound to `jump` (the action body runs as usual).
If the clip is already playing it restarts. Looping clips keep playing until Stop.

## Rules
- The host calls a hook whenever a user-declared action starts (`NxInterpreter(onAction = ...)`).
  Built-in functions (`spawn`, `sqrt`, ...) do not trigger clips.
- The per-frame `update` hook also counts as an action call, so do not bind a clip to `update`.
- Animations are applied after the script's `update` each frame, so they win over `setPos` on the same object.
- Interpolation is linear. Rotation is interpolated as Euler degrees (no shortest-path or quaternion blending).
- Clips target objects by id. Deleted objects are skipped.
- Clips are stored in the project file (.nxf, key `animations`, schema still 1; old files load with no clips).

## Animate mode
Cube button (top right of the viewport) -> Edit / Animate.
In Animate mode: pose the selected object with the gizmo, move the timeline cursor, tap Add key.
Moving the cursor poses all animated objects. Leaving Animate mode (or pressing Run) puts animated objects back
to the rest pose they had when Animate mode was entered; autosave also stores the rest pose.

## Not done
Easing curves, key dragging on the timeline, copy/paste keys, animating colour, blending several clips,
stopping a clip from NX (a new `game` function would need your approval).
