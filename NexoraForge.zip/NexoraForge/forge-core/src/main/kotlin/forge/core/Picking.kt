package forge.core

import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

operator fun Vec3.plus(o: Vec3) = Vec3(x + o.x, y + o.y, z + o.z)
operator fun Vec3.minus(o: Vec3) = Vec3(x - o.x, y - o.y, z - o.z)
operator fun Vec3.times(s: Float) = Vec3(x * s, y * s, z * s)
fun Vec3.dot(o: Vec3): Float = x * o.x + y * o.y + z * o.z
fun Vec3.cross(o: Vec3) = Vec3(y * o.z - z * o.y, z * o.x - x * o.z, x * o.y - y * o.x)
fun Vec3.length(): Float = sqrt(dot(this))
fun Vec3.normalized(): Vec3 {
    val l = length()
    return if (l < 1e-8f) this else this * (1f / l)
}

data class Ray(val origin: Vec3, val dir: Vec3)

/** Camera math that mirrors the renderer: orbit around (0, 0.5, 0), vertical FOV 50 degrees. */
object CameraMath {
    const val FOV_DEG = 50f
    val TARGET = Vec3(0f, 0.5f, 0f)

    fun eye(cam: OrbitCamera): Vec3 {
        val yaw = Math.toRadians(cam.yaw.toDouble())
        val pitch = Math.toRadians(cam.pitch.toDouble())
        val d = cam.distance.toDouble()
        return Vec3(
            (d * cos(pitch) * sin(yaw)).toFloat(),
            (d * sin(pitch) + 0.5).toFloat(),
            (d * cos(pitch) * cos(yaw)).toFloat()
        )
    }

    /** World ray through the screen point ([sx], [sy]) in pixels of a [w] x [h] viewport. */
    fun ray(cam: OrbitCamera, sx: Float, sy: Float, w: Float, h: Float): Ray {
        val e = eye(cam)
        val f = (TARGET - e).normalized()
        val r = f.cross(Vec3(0f, 1f, 0f)).normalized()
        val u = r.cross(f)
        val aspect = w / h
        val th = tan(Math.toRadians(FOV_DEG / 2.0)).toFloat()
        val nx = 2f * sx / w - 1f
        val ny = 1f - 2f * sy / h
        return Ray(e, (f + r * (nx * th * aspect) + u * (ny * th)).normalized())
    }
}

object Picking {
    // Same rotation order as the renderer: model = T * Ry * Rx * Rz * S.
    private fun rotX(v: Vec3, deg: Float): Vec3 {
        val a = Math.toRadians(deg.toDouble())
        val c = cos(a).toFloat()
        val s = sin(a).toFloat()
        return Vec3(v.x, v.y * c - v.z * s, v.y * s + v.z * c)
    }

    private fun rotY(v: Vec3, deg: Float): Vec3 {
        val a = Math.toRadians(deg.toDouble())
        val c = cos(a).toFloat()
        val s = sin(a).toFloat()
        return Vec3(v.x * c + v.z * s, v.y, -v.x * s + v.z * c)
    }

    private fun rotZ(v: Vec3, deg: Float): Vec3 {
        val a = Math.toRadians(deg.toDouble())
        val c = cos(a).toFloat()
        val s = sin(a).toFloat()
        return Vec3(v.x * c - v.y * s, v.x * s + v.y * c, v.z)
    }

    /** World vector -> object local vector (rotation and scale removed). */
    private fun toLocal(v: Vec3, o: SceneObject): Vec3 {
        val r = rotZ(rotX(rotY(v, -o.rotation.y), -o.rotation.x), -o.rotation.z)
        return Vec3(
            r.x / o.scale.x.coerceAtLeast(1e-4f),
            r.y / o.scale.y.coerceAtLeast(1e-4f),
            r.z / o.scale.z.coerceAtLeast(1e-4f)
        )
    }

    private fun slab(o: Vec3, d: Vec3, hx: Float, hy: Float, hz: Float): Float? {
        var tmin = Float.NEGATIVE_INFINITY
        var tmax = Float.POSITIVE_INFINITY
        val os = floatArrayOf(o.x, o.y, o.z)
        val ds = floatArrayOf(d.x, d.y, d.z)
        val hs = floatArrayOf(hx, hy, hz)
        for (i in 0..2) {
            if (abs(ds[i]) < 1e-8f) {
                if (abs(os[i]) > hs[i]) return null
            } else {
                val t1 = (-hs[i] - os[i]) / ds[i]
                val t2 = (hs[i] - os[i]) / ds[i]
                tmin = max(tmin, min(t1, t2))
                tmax = min(tmax, max(t1, t2))
            }
        }
        if (tmax < 0f || tmin > tmax) return null
        return max(tmin, 0f)
    }

    private fun sphere(o: Vec3, d: Vec3, r: Float): Float? {
        val a = d.dot(d)
        val b = o.dot(d)
        val c = o.dot(o) - r * r
        val disc = b * b - a * c
        if (disc < 0f) return null
        val sq = sqrt(disc)
        var t = (-b - sq) / a
        if (t < 0f) t = (-b + sq) / a
        return if (t < 0f) null else t
    }

    /** Distance along the ray to the object, or null if missed. Cube/sphere: 1 unit, plane: thin box. */
    fun hit(ray: Ray, o: SceneObject): Float? {
        val lo = toLocal(ray.origin - o.position, o)
        val ld = toLocal(ray.dir, o)
        return when (o.shape) {
            Shape.CUBE -> slab(lo, ld, 0.5f, 0.5f, 0.5f)
            Shape.PLANE -> slab(lo, ld, 0.5f, 0.02f, 0.5f)
            Shape.SPHERE -> sphere(lo, ld, 0.5f)
        }
    }

    /** Id of the nearest object under the ray, or null. */
    fun pick(ray: Ray, objects: List<SceneObject>): Int? {
        var best: Int? = null
        var bestT = Float.POSITIVE_INFINITY
        for (o in objects) {
            val t = hit(ray, o) ?: continue
            if (t < bestT) {
                bestT = t
                best = o.id
            }
        }
        return best
    }
}

enum class GizmoMode { MOVE, ROTATE, SCALE }

enum class Axis(val dir: Vec3) {
    X(Vec3(1f, 0f, 0f)),
    Y(Vec3(0f, 1f, 0f)),
    Z(Vec3(0f, 0f, 1f))
}

/** Gizmo handles are in world axes. Rotation rings edit the object's X/Y/Z Euler angles directly. */
object GizmoMath {
    const val RING_RADIUS = 0.9f

    /** World size of the gizmo; keeps it a constant size on screen. */
    fun size(eye: Vec3, center: Vec3): Float = max((eye - center).length() * 0.18f, 0.05f)

    /** Parameter s of the point on the axis line (center + dir * s) that is closest to the ray line. */
    fun axisParam(ray: Ray, center: Vec3, dir: Vec3): Float? {
        val d = ray.dir
        val w0 = ray.origin - center
        val a = d.dot(d)
        val b = d.dot(dir)
        val c = dir.dot(dir)
        val dd = d.dot(w0)
        val e = dir.dot(w0)
        val denom = a * c - b * b
        if (abs(denom) < 1e-6f) return null
        return (a * e - b * dd) / denom
    }

    /** Point where the ray crosses the plane through [center] with normal [normal]. */
    fun planePoint(ray: Ray, center: Vec3, normal: Vec3): Vec3? {
        val den = ray.dir.dot(normal)
        if (abs(den) < 1e-6f) return null
        val t = (center - ray.origin).dot(normal) / den
        if (t < 0f) return null
        return ray.origin + ray.dir * t
    }

    private fun distToRay(ray: Ray, p: Vec3): Float {
        val w = p - ray.origin
        val t = w.dot(ray.dir)
        return (w - ray.dir * t).length()
    }

    fun hitHandle(mode: GizmoMode, ray: Ray, center: Vec3, size: Float): Axis? {
        var best: Axis? = null
        var bestScore = Float.POSITIVE_INFINITY
        for (axis in Axis.values()) {
            val score: Float = when (mode) {
                GizmoMode.MOVE, GizmoMode.SCALE -> {
                    val s = axisParam(ray, center, axis.dir) ?: continue
                    if (s < 0.15f * size || s > 1.15f * size) continue
                    val d = distToRay(ray, center + axis.dir * s)
                    if (d > 0.12f * size) continue
                    d
                }
                GizmoMode.ROTATE -> {
                    val p = planePoint(ray, center, axis.dir) ?: continue
                    val err = abs((p - center).length() - RING_RADIUS * size)
                    if (err > 0.12f * size) continue
                    err
                }
            }
            if (score < bestScore) {
                bestScore = score
                best = axis
            }
        }
        return best
    }
}

/** One handle drag. Create with [begin] on touch-down, call [update] on every move. */
class GizmoDrag private constructor(
    private val mode: GizmoMode,
    private val axis: Axis,
    private val start: SceneObject,
    private val startParam: Float,
    private val startAngle: Float
) {
    private var lastAngle = startAngle
    private var accumulated = 0f

    private fun basis(): Pair<Vec3, Vec3> = when (axis) {
        Axis.X -> Pair(Axis.Y.dir, Axis.Z.dir)
        Axis.Y -> Pair(Axis.Z.dir, Axis.X.dir)
        Axis.Z -> Pair(Axis.X.dir, Axis.Y.dir)
    }

    private fun withAxis(v: Vec3, value: Float): Vec3 = when (axis) {
        Axis.X -> v.copy(x = value)
        Axis.Y -> v.copy(y = value)
        Axis.Z -> v.copy(z = value)
    }

    private fun pick(v: Vec3): Float = when (axis) {
        Axis.X -> v.x
        Axis.Y -> v.y
        Axis.Z -> v.z
    }

    /** Object with the drag applied (based on the state at drag start). */
    fun update(ray: Ray): SceneObject {
        val center = start.position
        when (mode) {
            GizmoMode.MOVE -> {
                val s = GizmoMath.axisParam(ray, center, axis.dir) ?: return start
                return start.copy(position = start.position + axis.dir * (s - startParam))
            }
            GizmoMode.SCALE -> {
                val s = GizmoMath.axisParam(ray, center, axis.dir) ?: return start
                val factor = s / startParam
                val v = (pick(start.scale) * factor).coerceAtLeast(0.01f)
                return start.copy(scale = withAxis(start.scale, v))
            }
            GizmoMode.ROTATE -> {
                val p = GizmoMath.planePoint(ray, center, axis.dir) ?: return start
                val (e1, e2) = basis()
                val v = p - center
                val a = atan2(v.dot(e2), v.dot(e1))
                var d = a - lastAngle
                val pi = Math.PI.toFloat()
                while (d > pi) d -= 2 * pi
                while (d < -pi) d += 2 * pi
                accumulated += d
                lastAngle = a
                val deg = Math.toDegrees(accumulated.toDouble()).toFloat()
                return start.copy(rotation = withAxis(start.rotation, pick(start.rotation) + deg))
            }
        }
    }

    companion object {
        fun begin(mode: GizmoMode, axis: Axis, obj: SceneObject, ray: Ray): GizmoDrag? {
            val center = obj.position
            return when (mode) {
                GizmoMode.MOVE, GizmoMode.SCALE -> {
                    val s = GizmoMath.axisParam(ray, center, axis.dir) ?: return null
                    if (mode == GizmoMode.SCALE && abs(s) < 1e-4f) return null
                    GizmoDrag(mode, axis, obj, s, 0f)
                }
                GizmoMode.ROTATE -> {
                    val p = GizmoMath.planePoint(ray, center, axis.dir) ?: return null
                    val probe = GizmoDrag(mode, axis, obj, 0f, 0f)
                    val (e1, e2) = probe.basis()
                    val v = p - center
                    GizmoDrag(mode, axis, obj, 0f, atan2(v.dot(e2), v.dot(e1)))
                }
            }
        }
    }
}
