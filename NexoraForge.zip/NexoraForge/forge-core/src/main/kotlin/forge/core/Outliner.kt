package forge.core

/** One visible line of the Outliner tree. */
sealed class OutlinerRow {
    abstract val depth: Int

    data class FolderRow(val folder: Folder, override val depth: Int, val expanded: Boolean, val childCount: Int) : OutlinerRow()
    data class ObjectRow(val obj: SceneObject, override val depth: Int) : OutlinerRow()
}

/**
 * Flattens folders and objects into the visible rows of the Outliner.
 * Folders come first at each level, then objects, both in creation order.
 * Children of collapsed folders are skipped.
 */
fun outlinerRows(objects: List<SceneObject>, folders: List<Folder>, expanded: Set<Int>): List<OutlinerRow> {
    val folderIds = folders.mapTo(HashSet()) { it.id }
    val rows = ArrayList<OutlinerRow>()

    fun walk(parent: Int?, depth: Int) {
        val subFolders = folders.filter { f ->
            if (parent == null) f.parentId == null || f.parentId !in folderIds else f.parentId == parent
        }
        for (f in subFolders) {
            val kids = folders.count { it.parentId == f.id } + objects.count { it.folderId == f.id }
            val open = f.id in expanded
            rows.add(OutlinerRow.FolderRow(f, depth, open, kids))
            if (open) walk(f.id, depth + 1)
        }
        val objs = objects.filter { o ->
            if (parent == null) o.folderId == null || o.folderId !in folderIds else o.folderId == parent
        }
        for (o in objs) rows.add(OutlinerRow.ObjectRow(o, depth))
    }

    walk(null, 0)
    return rows
}
