package forge.core

import nx.NativeFunction
import nx.NxException
import nx.Stdlib
import nx.typeName

/**
 * NX module `game` (EXPERIMENTAL, API not frozen). Enabled in a script with `load game`.
 *
 * Objects are addressed by Int id returned from `spawn`.
 */
object GameModule {
    private fun f(v: Any?, fn: String): Float = Stdlib.num(v, fn).toFloat()

    private fun id(v: Any?, fn: String): Int {
        if (v !is Long) throw NxException("NX4008", "$fn expects an Int object id but got ${typeName(v)}")
        return v.toInt()
    }

    private fun text(v: Any?, fn: String): String {
        if (v !is String) throw NxException("NX4008", "$fn expects Text but got ${typeName(v)}")
        return v
    }

    fun modules(scene: Scene, clock: GameClock): Map<String, List<NativeFunction>> {
        fun upd(objId: Int, change: (SceneObject) -> SceneObject) {
            if (!scene.update(objId, change)) throw NxException("NX9031", "no object with id $objId")
        }

        fun obj(objId: Int): SceneObject =
            scene.get(objId) ?: throw NxException("NX9031", "no object with id $objId")

        val game = listOf(
            NativeFunction("spawn", 5) { a ->
                val shapeName = text(a[1], "spawn")
                val shape = Shape.fromName(shapeName)
                    ?: throw NxException("NX9030", "unknown shape '$shapeName' (use cube, sphere or plane)")
                val o = scene.add(
                    text(a[0], "spawn"),
                    shape,
                    Vec3(f(a[2], "spawn"), f(a[3], "spawn"), f(a[4], "spawn"))
                )
                o.id.toLong()
            },
            NativeFunction("destroy", 1) { a ->
                val objId = id(a[0], "destroy")
                if (!scene.remove(objId)) throw NxException("NX9031", "no object with id $objId")
                null
            },
            NativeFunction("setPos", 4) { a ->
                val v = Vec3(f(a[1], "setPos"), f(a[2], "setPos"), f(a[3], "setPos"))
                upd(id(a[0], "setPos")) { it.copy(position = v) }
                null
            },
            NativeFunction("setRot", 4) { a ->
                val v = Vec3(f(a[1], "setRot"), f(a[2], "setRot"), f(a[3], "setRot"))
                upd(id(a[0], "setRot")) { it.copy(rotation = v) }
                null
            },
            NativeFunction("setScale", 4) { a ->
                val v = Vec3(f(a[1], "setScale"), f(a[2], "setScale"), f(a[3], "setScale"))
                upd(id(a[0], "setScale")) { it.copy(scale = v) }
                null
            },
            NativeFunction("setColor", 4) { a ->
                val v = Vec3(
                    f(a[1], "setColor").coerceIn(0f, 1f),
                    f(a[2], "setColor").coerceIn(0f, 1f),
                    f(a[3], "setColor").coerceIn(0f, 1f)
                )
                upd(id(a[0], "setColor")) { it.copy(color = v) }
                null
            },
            NativeFunction("getX", 1) { a -> obj(id(a[0], "getX")).position.x.toDouble() },
            NativeFunction("getY", 1) { a -> obj(id(a[0], "getY")).position.y.toDouble() },
            NativeFunction("getZ", 1) { a -> obj(id(a[0], "getZ")).position.z.toDouble() },
            NativeFunction("deltaTime", 0) { _ -> clock.delta.toDouble() },
            NativeFunction("elapsed", 0) { _ -> clock.elapsed.toDouble() }
        )
        return mapOf("game" to game)
    }
}
