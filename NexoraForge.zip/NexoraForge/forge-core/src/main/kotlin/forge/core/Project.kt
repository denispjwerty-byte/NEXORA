package forge.core

import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject

/** One NX script file inside a project. [name] always ends with ".nx". */
data class NxScriptFile(val name: String, val text: String)

/** Everything stored in a project file (.nxf). */
data class ProjectData(
    val name: String,
    val scripts: List<NxScriptFile>,
    val activeScript: Int,
    val scene: SceneState
)

class ProjectFormatException(message: String) : Exception(message)

/** Project file format .nxf: JSON with a schema version. Current schema: 1. */
object ProjectFormat {
    const val SCHEMA = 1

    fun normalizeScriptName(raw: String): String {
        var n = raw.trim().replace('/', '_').replace('\\', '_')
        if (n.endsWith(".nx", ignoreCase = true)) n = n.dropLast(3).trim()
        if (n.isEmpty()) n = "script"
        return "$n.nx"
    }

    /** Returns [wanted] normalized and made unique among [existing] names (script.nx, script 2.nx, ...). */
    fun uniqueScriptName(wanted: String, existing: Collection<String>): String {
        val base = normalizeScriptName(wanted).dropLast(3)
        var candidate = "$base.nx"
        var i = 2
        while (existing.any { it.equals(candidate, ignoreCase = true) }) {
            candidate = "$base $i.nx"
            i++
        }
        return candidate
    }

    fun toJson(p: ProjectData): String {
        val root = JSONObject()
        root.put("schema", SCHEMA)
        root.put("name", p.name)
        root.put("activeScript", p.activeScript)
        val scripts = JSONArray()
        for (s in p.scripts) scripts.put(JSONObject().put("name", s.name).put("text", s.text))
        root.put("scripts", scripts)

        val scene = JSONObject()
        scene.put("nextId", p.scene.nextId)
        scene.put("nextFolderId", p.scene.nextFolderId)
        val folders = JSONArray()
        for (f in p.scene.folders) {
            val j = JSONObject().put("id", f.id).put("name", f.name)
            if (f.parentId != null) j.put("parent", f.parentId)
            folders.put(j)
        }
        scene.put("folders", folders)
        val objects = JSONArray()
        for (o in p.scene.objects) {
            val j = JSONObject()
                .put("id", o.id)
                .put("name", o.name)
                .put("shape", o.shape.label)
                .put("position", vec(o.position))
                .put("rotation", vec(o.rotation))
                .put("scale", vec(o.scale))
                .put("color", vec(o.color))
            if (o.folderId != null) j.put("folder", o.folderId)
            objects.put(j)
        }
        scene.put("objects", objects)
        root.put("scene", scene)
        return root.toString(2)
    }

    fun fromJson(text: String): ProjectData {
        try {
            val root = JSONObject(text)
            val schema = root.optInt("schema", -1)
            if (schema < 1) throw ProjectFormatException("Not a Nexora project file (no schema)")
            if (schema > SCHEMA) throw ProjectFormatException("Project schema $schema is newer than supported ($SCHEMA)")

            val scripts = ArrayList<NxScriptFile>()
            val sArr = root.optJSONArray("scripts") ?: JSONArray()
            for (i in 0 until sArr.length()) {
                val j = sArr.getJSONObject(i)
                val name = uniqueScriptName(j.optString("name", "script"), scripts.map { it.name })
                scripts.add(NxScriptFile(name, j.optString("text", "")))
            }

            val scene = root.optJSONObject("scene") ?: JSONObject()
            val folders = ArrayList<Folder>()
            val fArr = scene.optJSONArray("folders") ?: JSONArray()
            for (i in 0 until fArr.length()) {
                val j = fArr.getJSONObject(i)
                folders.add(Folder(j.getInt("id"), j.optString("name", "Folder"), if (j.has("parent")) j.getInt("parent") else null))
            }
            val objects = ArrayList<SceneObject>()
            val oArr = scene.optJSONArray("objects") ?: JSONArray()
            for (i in 0 until oArr.length()) {
                val j = oArr.getJSONObject(i)
                val shape = Shape.fromName(j.optString("shape", "")) ?: throw ProjectFormatException("Unknown shape in object ${j.optInt("id")}")
                objects.add(
                    SceneObject(
                        id = j.getInt("id"),
                        name = j.optString("name", "Object"),
                        shape = shape,
                        position = readVec(j, "position", Vec3.ZERO),
                        rotation = readVec(j, "rotation", Vec3.ZERO),
                        scale = readVec(j, "scale", Vec3.ONE),
                        color = readVec(j, "color", defaultColor(shape)),
                        folderId = if (j.has("folder")) j.getInt("folder") else null
                    )
                )
            }
            val nextId = maxOf(scene.optInt("nextId", 1), (objects.maxOfOrNull { it.id } ?: 0) + 1)
            val nextFolderId = maxOf(scene.optInt("nextFolderId", 1), (folders.maxOfOrNull { it.id } ?: 0) + 1)
            val active = root.optInt("activeScript", 0).coerceIn(0, maxOf(0, scripts.size - 1))
            return ProjectData(
                name = root.optString("name", "Project").ifBlank { "Project" },
                scripts = scripts,
                activeScript = active,
                scene = SceneState(objects, nextId, folders, nextFolderId)
            )
        } catch (e: JSONException) {
            throw ProjectFormatException("Broken project file: ${e.message}")
        }
    }

    private fun vec(v: Vec3) = JSONArray().put(v.x.toDouble()).put(v.y.toDouble()).put(v.z.toDouble())

    private fun readVec(j: JSONObject, key: String, default: Vec3): Vec3 {
        val a = j.optJSONArray(key) ?: return default
        if (a.length() != 3) return default
        return Vec3(a.getDouble(0).toFloat(), a.getDouble(1).toFloat(), a.getDouble(2).toFloat())
    }
}
