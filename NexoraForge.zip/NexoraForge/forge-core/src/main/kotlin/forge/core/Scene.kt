package forge.core

data class Vec3(val x: Float, val y: Float, val z: Float) {
    companion object {
        val ZERO = Vec3(0f, 0f, 0f)
        val ONE = Vec3(1f, 1f, 1f)
    }
}

enum class Shape(val label: String) {
    CUBE("cube"),
    SPHERE("sphere"),
    PLANE("plane");

    companion object {
        fun fromName(name: String): Shape? {
            val n = name.trim().lowercase()
            return values().firstOrNull { it.label == n }
        }
    }
}

data class SceneObject(
    val id: Int,
    val name: String,
    val shape: Shape,
    val position: Vec3,
    val rotation: Vec3,
    val scale: Vec3,
    val color: Vec3
)

data class SceneState(val objects: List<SceneObject>, val nextId: Int)

fun defaultColor(shape: Shape): Vec3 = when (shape) {
    Shape.CUBE -> Vec3(0.55f, 0.6f, 0.85f)
    Shape.SPHERE -> Vec3(0.85f, 0.55f, 0.6f)
    Shape.PLANE -> Vec3(0.3f, 0.33f, 0.45f)
}

/**
 * Flat scene: a list of immutable objects. The list is replaced atomically on every change,
 * so the renderer thread can safely read [objects] at any time.
 */
class Scene {
    @Volatile
    var objects: List<SceneObject> = emptyList()
        private set

    private var nextId = 1

    @Volatile
    var onChange: (() -> Unit)? = null

    fun add(
        name: String,
        shape: Shape,
        position: Vec3 = Vec3.ZERO,
        scale: Vec3 = Vec3.ONE,
        color: Vec3 = defaultColor(shape)
    ): SceneObject {
        val obj = synchronized(this) {
            val o = SceneObject(nextId++, name.ifBlank { "Object" }, shape, position, Vec3.ZERO, scale, color)
            objects = objects + o
            o
        }
        onChange?.invoke()
        return obj
    }

    fun get(id: Int): SceneObject? = objects.firstOrNull { it.id == id }

    fun update(id: Int, change: (SceneObject) -> SceneObject): Boolean {
        val found = synchronized(this) {
            val current = objects.firstOrNull { it.id == id }
            if (current == null) {
                false
            } else {
                val updated = change(current)
                objects = objects.map { if (it.id == id) updated else it }
                true
            }
        }
        if (found) onChange?.invoke()
        return found
    }

    fun remove(id: Int): Boolean {
        val removed = synchronized(this) {
            val before = objects.size
            objects = objects.filter { it.id != id }
            objects.size != before
        }
        if (removed) onChange?.invoke()
        return removed
    }

    fun capture(): SceneState = synchronized(this) { SceneState(objects, nextId) }

    fun restore(state: SceneState) {
        synchronized(this) {
            objects = state.objects
            nextId = state.nextId
        }
        onChange?.invoke()
    }
}

/** Time source for scripts. Written by the engine each frame, read by NX (`deltaTime`, `elapsed`). */
class GameClock {
    @Volatile
    var delta: Float = 0f

    @Volatile
    var elapsed: Float = 0f

    fun advance(dt: Float) {
        delta = dt
        elapsed += dt
    }

    fun reset() {
        delta = 0f
        elapsed = 0f
    }
}

/** Orbit camera state shared between the touch handler (UI thread) and the renderer (GL thread). */
class OrbitCamera {
    @Volatile
    var yaw: Float = 35f

    @Volatile
    var pitch: Float = 25f

    @Volatile
    var distance: Float = 9f

    fun orbit(dx: Float, dy: Float) {
        yaw -= dx * 0.4f
        pitch = (pitch + dy * 0.4f).coerceIn(-85f, 85f)
    }

    fun zoom(scaleFactor: Float) {
        distance = (distance / scaleFactor).coerceIn(2f, 60f)
    }
}
