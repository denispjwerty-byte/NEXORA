package forge.core

data class Vec3(val x: Float, val y: Float, val z: Float) {
    companion object {
        val ZERO = Vec3(0f, 0f, 0f)
        val ONE = Vec3(1f, 1f, 1f)
    }
}

enum class Shape(val label: String) {
    CUBE("cube"),
    SPHERE("sphere"),
    PLANE("plane");

    companion object {
        fun fromName(name: String): Shape? {
            val n = name.trim().lowercase()
            return values().firstOrNull { it.label == n }
        }
    }
}

data class SceneObject(
    val id: Int,
    val name: String,
    val shape: Shape,
    val position: Vec3,
    val rotation: Vec3,
    val scale: Vec3,
    val color: Vec3,
    /** Outliner folder this object lives in; null = root. Folders only group, they do not transform. */
    val folderId: Int? = null
)

data class Folder(val id: Int, val name: String, val parentId: Int? = null)

data class SceneState(
    val objects: List<SceneObject>,
    val nextId: Int,
    val folders: List<Folder> = emptyList(),
    val nextFolderId: Int = 1
)

fun defaultColor(shape: Shape): Vec3 = when (shape) {
    Shape.CUBE -> Vec3(0.55f, 0.6f, 0.85f)
    Shape.SPHERE -> Vec3(0.85f, 0.55f, 0.6f)
    Shape.PLANE -> Vec3(0.3f, 0.33f, 0.45f)
}

/**
 * Flat scene: a list of immutable objects. The list is replaced atomically on every change,
 * so the renderer thread can safely read [objects] at any time.
 */
class Scene {
    @Volatile
    var objects: List<SceneObject> = emptyList()
        private set

    @Volatile
    var folders: List<Folder> = emptyList()
        private set

    private var nextId = 1
    private var nextFolderId = 1

    @Volatile
    var onChange: (() -> Unit)? = null

    fun add(
        name: String,
        shape: Shape,
        position: Vec3 = Vec3.ZERO,
        scale: Vec3 = Vec3.ONE,
        color: Vec3 = defaultColor(shape),
        folderId: Int? = null
    ): SceneObject {
        val obj = synchronized(this) {
            val fid = if (folderId != null && folders.any { it.id == folderId }) folderId else null
            val o = SceneObject(nextId++, name.ifBlank { "Object" }, shape, position, Vec3.ZERO, scale, color, fid)
            objects = objects + o
            o
        }
        onChange?.invoke()
        return obj
    }

    fun get(id: Int): SceneObject? = objects.firstOrNull { it.id == id }

    fun update(id: Int, change: (SceneObject) -> SceneObject): Boolean {
        val found = synchronized(this) {
            val current = objects.firstOrNull { it.id == id }
            if (current == null) {
                false
            } else {
                val updated = change(current)
                objects = objects.map { if (it.id == id) updated else it }
                true
            }
        }
        if (found) onChange?.invoke()
        return found
    }

    fun remove(id: Int): Boolean {
        val removed = synchronized(this) {
            val before = objects.size
            objects = objects.filter { it.id != id }
            objects.size != before
        }
        if (removed) onChange?.invoke()
        return removed
    }

    // ---------- folders (Outliner) ----------

    fun getFolder(id: Int): Folder? = folders.firstOrNull { it.id == id }

    fun addFolder(name: String, parentId: Int? = null): Folder {
        val f = synchronized(this) {
            val pid = if (parentId != null && folders.any { it.id == parentId }) parentId else null
            val created = Folder(nextFolderId++, name.trim().ifBlank { "Folder" }, pid)
            folders = folders + created
            created
        }
        onChange?.invoke()
        return f
    }

    fun renameFolder(id: Int, name: String): Boolean {
        val clean = name.trim()
        if (clean.isEmpty()) return false
        val ok = synchronized(this) {
            if (folders.none { it.id == id }) {
                false
            } else {
                folders = folders.map { if (it.id == id) it.copy(name = clean) else it }
                true
            }
        }
        if (ok) onChange?.invoke()
        return ok
    }

    /** True if [candidate] is [folderId] itself or lies inside it (used to forbid cycles). */
    fun isInside(candidate: Int?, folderId: Int): Boolean {
        var cur = candidate
        var guard = 0
        while (cur != null && guard++ < 10_000) {
            if (cur == folderId) return true
            cur = folders.firstOrNull { it.id == cur }?.parentId
        }
        return false
    }

    /** Moves an object into a folder (null = root). */
    fun moveObject(id: Int, folderId: Int?): Boolean {
        if (folderId != null && getFolder(folderId) == null) return false
        return update(id) { it.copy(folderId = folderId) }
    }

    /** Moves a folder into another folder (null = root). Refuses moves that would create a cycle. */
    fun moveFolder(id: Int, newParentId: Int?): Boolean {
        val ok = synchronized(this) {
            if (folders.none { it.id == id }) {
                false
            } else if (newParentId != null && (folders.none { it.id == newParentId } || isInside(newParentId, id))) {
                false
            } else {
                folders = folders.map { if (it.id == id) it.copy(parentId = newParentId) else it }
                true
            }
        }
        if (ok) onChange?.invoke()
        return ok
    }

    /** Deletes a folder. Its objects and sub-folders move up to the deleted folder's parent. */
    fun removeFolder(id: Int): Boolean {
        val ok = synchronized(this) {
            val f = folders.firstOrNull { it.id == id }
            if (f == null) {
                false
            } else {
                folders = folders.filter { it.id != id }
                    .map { if (it.parentId == id) it.copy(parentId = f.parentId) else it }
                objects = objects.map { if (it.folderId == id) it.copy(folderId = f.parentId) else it }
                true
            }
        }
        if (ok) onChange?.invoke()
        return ok
    }

    fun capture(): SceneState = synchronized(this) { SceneState(objects, nextId, folders, nextFolderId) }

    fun restore(state: SceneState) {
        synchronized(this) {
            objects = state.objects
            nextId = state.nextId
            folders = state.folders
            nextFolderId = state.nextFolderId
        }
        onChange?.invoke()
    }
}

/** Time source for scripts. Written by the engine each frame, read by NX (`deltaTime`, `elapsed`). */
class GameClock {
    @Volatile
    var delta: Float = 0f

    @Volatile
    var elapsed: Float = 0f

    fun advance(dt: Float) {
        delta = dt
        elapsed += dt
    }

    fun reset() {
        delta = 0f
        elapsed = 0f
    }
}

/** Orbit camera state shared between the touch handler (UI thread) and the renderer (GL thread). */
class OrbitCamera {
    @Volatile
    var yaw: Float = 35f

    @Volatile
    var pitch: Float = 25f

    @Volatile
    var distance: Float = 9f

    fun orbit(dx: Float, dy: Float) {
        yaw -= dx * 0.4f
        pitch = (pitch + dy * 0.4f).coerceIn(-85f, 85f)
    }

    fun zoom(scaleFactor: Float) {
        distance = (distance / scaleFactor).coerceIn(2f, 60f)
    }
}
