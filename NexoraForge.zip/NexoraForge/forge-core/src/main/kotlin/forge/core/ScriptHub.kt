package forge.core

import nx.NativeFunction
import nx.Nx
import nx.NxException
import nx.NxInterpreter
import nx.typeName

/**
 * Runs several NX scripts of one project side by side and lets them talk to each other.
 *
 * Every started script has its own [NxInterpreter] (its own variables and actions), but all of them
 * share the same engine modules (`game`: one scene, one clock). Scripts reach each other only through
 * the NX module `scripts` (`load scripts`), which this class provides. No NX syntax was added.
 *
 * Mechanisms (see docs/SCRIPTS.md):
 *  - lifecycle:  startScript, stopScript, isRunning, hasScript, scriptNames, selfName
 *  - calls:      callScript "script", "action", args...   (synchronous, returns the action's value)
 *  - messages:   send "script", "topic", value / inboxCount / receive / clearInbox   (asynchronous mailbox)
 *  - events:     on "event", "action" / off "event" / emit "event", args...   (publish / subscribe)
 *  - shared data: share "key", value / shared "key" / hasShared "key" / unshare "key"
 *
 * Values that cross a script boundary (arguments, results, messages, events, shared data) are copied,
 * so two scripts never hold the same mutable List. Scripts are looked up by file name, case-insensitive,
 * with or without ".nx" ("enemy" and "Enemy.nx" are the same script).
 *
 * Not thread-safe: use from one thread (the UI/game thread), like [NxInterpreter].
 */
class ScriptHub(
    scripts: List<NxScriptFile>,
    private val baseModules: Map<String, List<NativeFunction>>,
    /** Receives (script file name, text) for every `say`. */
    private val out: (String, String) -> Unit,
    private val onAction: (String) -> Unit = {},
    private val stepLimit: Int = 2_000_000
) {
    companion object {
        const val MAX_CALL_DEPTH = 32
        const val MAX_INBOX = 1000
        const val MAX_SHARED = 1000
        const val MAX_VALUE_NESTING = 64
    }

    private class Instance(val key: String, val name: String, val interp: NxInterpreter)

    private class Message(val from: String, val topic: String, val value: Any?)

    private class Handler(val scriptKey: String, val action: String)

    private val sources = LinkedHashMap<String, NxScriptFile>()
    private val instances = LinkedHashMap<String, Instance>()
    private val inboxes = HashMap<String, ArrayDeque<Message>>()
    private val subscriptions = LinkedHashMap<String, MutableList<Handler>>()
    private val sharedData = LinkedHashMap<String, Any?>()
    private var depth = 0
    private var entryKey: String? = null

    init {
        for (s in scripts) sources[keyOf(s.name)] = s
    }

    /** File names of the scripts that are currently running, in start order. */
    val runningScripts: List<String> get() = instances.values.map { it.name }

    // ---------------------------------------------------------------- host API

    /**
     * Starts the entry script: parses it and runs its top level. Errors of the entry script are reported
     * exactly like a single-script run (no script-name prefix). Starting a running script does nothing.
     */
    fun start(name: String) {
        val key = keyOf(name)
        if (entryKey == null) entryKey = key
        startInstance(key, wrapErrors = key != entryKey)
    }

    /**
     * One frame: calls `action update` (or `action update dt`) of every running script, in start order.
     * A script stopped during the frame by another script is skipped.
     */
    fun update(dt: Float) {
        for (inst in instances.values.toList()) {
            if (instances[inst.key] !== inst) continue
            if (!inst.interp.hasAction("update")) continue
            val arity = inst.interp.actionArity("update") ?: 0
            val args: List<Any?> = listOf<Any?>(dt.toDouble()).take(arity)
            guarded(inst, wrapErrors = inst.key != entryKey) { inst.interp.callAction("update", args) }
        }
    }

    // ---------------------------------------------------------------- internals

    private fun keyOf(name: String): String = ProjectFormat.normalizeScriptName(name).lowercase()

    private fun <T> guarded(inst: Instance, wrapErrors: Boolean, block: () -> T): T {
        if (depth >= MAX_CALL_DEPTH) {
            throw NxException("NX9040", "script call depth limit ($MAX_CALL_DEPTH) exceeded")
        }
        depth++
        try {
            return block()
        } catch (e: NxException) {
            if (!wrapErrors) throw e
            throw NxException(e.code, "in script '${inst.name}': ${e.detail}", e.line, e.col)
        } finally {
            depth--
        }
    }

    private fun startInstance(key: String, wrapErrors: Boolean): Instance {
        instances[key]?.let { return it }
        val file = sources[key] ?: throw NxException("NX9042", "no script named '$key' in this project")
        val interp = NxInterpreter(
            out = { out(file.name, it) },
            modules = baseModules + mapOf("scripts" to scriptsModule(key)),
            stepLimit = stepLimit,
            onAction = onAction
        )
        val inst = Instance(key, file.name, interp)
        instances[key] = inst // registered first: a script that is starting can already be called, and start is idempotent
        try {
            guarded(inst, wrapErrors) { interp.run(Nx.parse(file.text)) }
        } catch (e: NxException) {
            forget(key)
            throw e
        }
        return inst
    }

    private fun forget(key: String) {
        instances.remove(key)
        inboxes.remove(key)
        for (list in subscriptions.values) list.removeAll { it.scriptKey == key }
        subscriptions.values.removeAll { it.isEmpty() }
    }

    private fun running(key: String, shown: String): Instance =
        instances[key] ?: throw NxException(
            "NX9041",
            "script '$shown' is not running (use 'run startScript' first)"
        )

    private fun findKey(raw: Any?, fn: String): String {
        val key = keyOf(text(raw, fn))
        if (key !in sources) throw NxException("NX9042", "no script named '${raw}' in this project")
        return key
    }

    private fun text(v: Any?, fn: String): String {
        if (v !is String) throw NxException("NX4008", "$fn expects Text but got ${typeName(v)}")
        return v
    }

    private fun needAtLeast(a: List<Any?>, n: Int, fn: String) {
        if (a.size < n) throw NxException("NX9004", "'$fn' expects at least $n argument(s) but got ${a.size}")
    }

    /** Deep copy of a value so that a List is never shared between scripts. */
    private fun copy(v: Any?, level: Int = 0): Any? {
        if (v !is List<*>) return v
        if (level >= MAX_VALUE_NESTING) {
            throw NxException("NX9046", "value is nested too deeply to pass between scripts")
        }
        val c = ArrayList<Any?>(v.size)
        for (item in v) c.add(copy(item, level + 1))
        return c
    }

    private fun copyAll(values: List<Any?>): List<Any?> = values.map { copy(it) }

    private fun callAction(inst: Instance, action: String, args: List<Any?>): Any? {
        if (!inst.interp.hasAction(action)) {
            throw NxException("NX9043", "script '${inst.name}' has no action '$action'")
        }
        return copy(guarded(inst, wrapErrors = true) { inst.interp.callAction(action, copyAll(args)) })
    }

    // ---------------------------------------------------------------- module `scripts`

    private fun scriptsModule(self: String): List<NativeFunction> {
        fun me(): Instance = instances[self]
            ?: throw NxException("NX9041", "script '${sources[self]?.name ?: self}' was stopped")

        return listOf(
            NativeFunction("selfName", 0) { _ -> sources[self]?.name ?: self },
            NativeFunction("scriptNames", 0) { _ -> ArrayList<Any?>(sources.values.map { it.name }) },
            NativeFunction("hasScript", 1) { a -> keyOf(text(a[0], "hasScript")) in sources },
            NativeFunction("isRunning", 1) { a -> keyOf(text(a[0], "isRunning")) in instances },
            NativeFunction("startScript", 1) { a ->
                startInstance(findKey(a[0], "startScript"), wrapErrors = true)
                null
            },
            NativeFunction("stopScript", 1) { a ->
                val key = findKey(a[0], "stopScript")
                if (key == self) {
                    throw NxException("NX9045", "a script cannot stop itself")
                }
                forget(key)
                null
            },

            // calls
            NativeFunction("callScript", -1) { a ->
                needAtLeast(a, 2, "callScript")
                val key = findKey(a[0], "callScript")
                val inst = running(key, text(a[0], "callScript"))
                callAction(inst, text(a[1], "callScript"), a.drop(2))
            },

            // messages
            NativeFunction("send", 3) { a ->
                val key = findKey(a[0], "send")
                val topic = text(a[1], "send")
                val box = inboxes.getOrPut(key) { ArrayDeque() }
                if (box.size >= MAX_INBOX) {
                    throw NxException("NX9047", "inbox of '${a[0]}' is full ($MAX_INBOX messages)")
                }
                box.addLast(Message(sources[self]?.name ?: self, topic, copy(a[2])))
                null
            },
            NativeFunction("inboxCount", 0) { _ -> (inboxes[self]?.size ?: 0).toLong() },
            NativeFunction("receive", 0) { _ ->
                val m = inboxes[self]?.removeFirstOrNull()
                    ?: throw NxException("NX9048", "inbox is empty (check 'run inboxCount' first)")
                arrayListOf<Any?>(m.from, m.topic, m.value)
            },
            NativeFunction("clearInbox", 0) { _ ->
                inboxes[self]?.clear()
                null
            },

            // events
            NativeFunction("on", 2) { a ->
                val event = text(a[0], "on")
                val action = text(a[1], "on")
                if (!me().interp.hasAction(action)) {
                    throw NxException("NX9043", "script '${me().name}' has no action '$action'")
                }
                val list = subscriptions.getOrPut(event) { ArrayList() }
                if (list.none { it.scriptKey == self && it.action == action }) list.add(Handler(self, action))
                null
            },
            NativeFunction("off", 1) { a ->
                val event = text(a[0], "off")
                val list = subscriptions[event]
                if (list != null) {
                    list.removeAll { it.scriptKey == self }
                    if (list.isEmpty()) subscriptions.remove(event)
                }
                null
            },
            NativeFunction("emit", -1) { a ->
                needAtLeast(a, 1, "emit")
                val event = text(a[0], "emit")
                val args = a.drop(1)
                var count = 0L
                for (h in subscriptions[event]?.toList() ?: emptyList()) {
                    val target = instances[h.scriptKey] ?: continue
                    callAction(target, h.action, args)
                    count++
                }
                count
            },

            // shared data
            NativeFunction("share", 2) { a ->
                val key = text(a[0], "share")
                if (key !in sharedData && sharedData.size >= MAX_SHARED) {
                    throw NxException("NX9047", "shared data is full ($MAX_SHARED keys)")
                }
                sharedData[key] = copy(a[1])
                null
            },
            NativeFunction("shared", 1) { a ->
                val key = text(a[0], "shared")
                if (key !in sharedData) throw NxException("NX9044", "no shared value named '$key'")
                copy(sharedData[key])
            },
            NativeFunction("hasShared", 1) { a -> text(a[0], "hasShared") in sharedData },
            NativeFunction("unshare", 1) { a ->
                sharedData.remove(text(a[0], "unshare"))
                null
            }
        )
    }
}
