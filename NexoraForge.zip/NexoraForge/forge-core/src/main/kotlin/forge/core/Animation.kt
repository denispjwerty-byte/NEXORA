package forge.core

/** One pose of an object at [time] seconds. Rotation is Euler degrees (same as SceneObject). */
data class Keyframe(val time: Float, val position: Vec3, val rotation: Vec3, val scale: Vec3)

/** Keyframes of one object, sorted by time. */
data class AnimTrack(val objectId: Int, val keys: List<Keyframe>)

/**
 * An animation clip. [action] is the name of the NX action that starts this clip:
 * when the script runs `run <action>`, the clip plays on its objects. Empty = not bound.
 */
data class AnimClip(
    val id: Int,
    val name: String,
    val action: String = "",
    val duration: Float = 2f,
    val loop: Boolean = false,
    val tracks: List<AnimTrack> = emptyList()
)

object Anim {
    /** Keys closer than this (seconds) count as the same key. */
    const val KEY_EPS = 0.02f
    const val MIN_DURATION = 0.1f

    private val ACTION_NAME = Regex("[A-Za-z_][A-Za-z0-9_]*")

    /** Accepts "jump" or "action jump"; returns "" for blank input. */
    fun normalizeAction(raw: String): String = raw.trim().removePrefix("action").trim()

    /** Empty (unbound) or a valid NX identifier. */
    fun isValidAction(name: String): Boolean = name.isEmpty() || ACTION_NAME.matches(name)

    /** True if some script declares `action <name>` at the start of a line. */
    fun declaresAction(scripts: List<NxScriptFile>, name: String): Boolean {
        if (name.isEmpty() || !isValidAction(name)) return false
        val re = Regex("(?m)^[ \\t]*action[ \\t]+" + Regex.escape(name) + "(?![A-Za-z0-9_])")
        return scripts.any { re.containsMatchIn(it.text) }
    }

    fun track(clip: AnimClip, objectId: Int): AnimTrack? = clip.tracks.firstOrNull { it.objectId == objectId }

    private fun pose(time: Float, o: SceneObject) = Keyframe(time, o.position, o.rotation, o.scale)

    /** Adds a key with the object's current transform at [time], or replaces the key already there. */
    fun setKey(clip: AnimClip, obj: SceneObject, time: Float): AnimClip {
        val t = time.coerceIn(0f, clip.duration)
        val key = pose(t, obj)
        val old = track(clip, obj.id)
        val keys = (old?.keys ?: emptyList()).filter { kotlin.math.abs(it.time - t) >= KEY_EPS } + key
        val track = AnimTrack(obj.id, keys.sortedBy { it.time })
        val tracks = if (old == null) clip.tracks + track else clip.tracks.map { if (it.objectId == obj.id) track else it }
        return clip.copy(tracks = tracks)
    }

    /** Removes the key at [time] (within [KEY_EPS]). An empty track is dropped. */
    fun removeKey(clip: AnimClip, objectId: Int, time: Float): AnimClip {
        val old = track(clip, objectId) ?: return clip
        val keys = old.keys.filter { kotlin.math.abs(it.time - time) >= KEY_EPS }
        val tracks = if (keys.isEmpty()) clip.tracks.filter { it.objectId != objectId }
        else clip.tracks.map { if (it.objectId == objectId) it.copy(keys = keys) else it }
        return clip.copy(tracks = tracks)
    }

    fun hasKeyAt(clip: AnimClip, objectId: Int, time: Float): Boolean =
        track(clip, objectId)?.keys?.any { kotlin.math.abs(it.time - time) < KEY_EPS } == true

    /** Latest key time in the clip (0 if there are none). */
    fun lastKeyTime(clip: AnimClip): Float = clip.tracks.maxOfOrNull { t -> t.keys.maxOfOrNull { it.time } ?: 0f } ?: 0f

    /** Sets the duration; it never goes below [MIN_DURATION] or below the last key, so no key is lost. */
    fun withDuration(clip: AnimClip, seconds: Float): AnimClip =
        clip.copy(duration = maxOf(seconds, MIN_DURATION, lastKeyTime(clip)))

    private fun lerp(a: Float, b: Float, f: Float) = a + (b - a) * f
    private fun lerp(a: Vec3, b: Vec3, f: Float) = Vec3(lerp(a.x, b.x, f), lerp(a.y, b.y, f), lerp(a.z, b.z, f))

    /** Pose of the track at [t]: linear between keys, held before the first and after the last key. */
    fun sample(track: AnimTrack, t: Float): Keyframe? {
        val keys = track.keys
        if (keys.isEmpty()) return null
        if (t <= keys.first().time) return keys.first().copy(time = t)
        if (t >= keys.last().time) return keys.last().copy(time = t)
        for (i in 0 until keys.size - 1) {
            val a = keys[i]
            val b = keys[i + 1]
            if (t >= a.time && t <= b.time) {
                val span = b.time - a.time
                val f = if (span <= 0f) 0f else (t - a.time) / span
                return Keyframe(t, lerp(a.position, b.position, f), lerp(a.rotation, b.rotation, f), lerp(a.scale, b.scale, f))
            }
        }
        return keys.last().copy(time = t)
    }

    /** Writes the clip's pose at [t] into the scene. Objects that no longer exist are skipped. */
    fun applyTo(scene: Scene, clip: AnimClip, t: Float) {
        for (tr in clip.tracks) {
            val k = sample(tr, t) ?: continue
            scene.update(tr.objectId) { it.copy(position = k.position, rotation = k.rotation, scale = k.scale) }
        }
    }

    /** Ids of all objects that have a track in any of [clips]. */
    fun animatedIds(clips: List<AnimClip>): Set<Int> = clips.flatMap { c -> c.tracks.map { it.objectId } }.toSet()

    /** [state] with the transforms of [ids] taken from [base] (used to save the rest pose while posing). */
    fun withRest(state: SceneState, base: SceneState, ids: Set<Int>): SceneState {
        val baseById = base.objects.associateBy { it.id }
        val objs = state.objects.map { o ->
            val b = baseById[o.id]
            if (o.id in ids && b != null) o.copy(position = b.position, rotation = b.rotation, scale = b.scale) else o
        }
        return state.copy(objects = objs)
    }
}

/**
 * Plays clips during Play mode. The host calls [trigger] when an NX action starts and [advance] once per frame.
 * Starting a clip that is already playing restarts it.
 */
class AnimationPlayer(private val scene: Scene) {
    private class Playing(val clip: AnimClip, var time: Float)

    private val playing = ArrayList<Playing>()

    val activeCount: Int get() = playing.size

    /** Starts every clip bound to [actionName]. Returns how many were started. */
    fun trigger(actionName: String, clips: List<AnimClip>): Int {
        var n = 0
        for (c in clips) {
            if (c.action.isEmpty() || c.action != actionName) continue
            playing.removeAll { it.clip.id == c.id }
            playing.add(Playing(c, 0f))
            Anim.applyTo(scene, c, 0f)
            n++
        }
        return n
    }

    fun advance(dt: Float) {
        if (playing.isEmpty()) return
        val it = playing.iterator()
        while (it.hasNext()) {
            val p = it.next()
            p.time += dt
            val d = p.clip.duration
            if (p.clip.loop && d > 0f) {
                Anim.applyTo(scene, p.clip, p.time % d)
            } else {
                Anim.applyTo(scene, p.clip, minOf(p.time, d))
                if (p.time >= d) it.remove()
            }
        }
    }

    fun stopAll() = playing.clear()
}
