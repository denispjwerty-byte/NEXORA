package forge.core

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertFalse
import kotlin.test.assertNull
import kotlin.test.assertTrue

class OutlinerAndProjectTest {
    @Test
    fun moveObjectIntoFolderAndRename() {
        val s = Scene()
        val f = s.addFolder("Enemies")
        val o = s.add("Box", Shape.CUBE)
        assertTrue(s.moveObject(o.id, f.id))
        assertEquals(f.id, s.get(o.id)?.folderId)
        assertTrue(s.renameFolder(f.id, "  Bad guys "))
        assertEquals("Bad guys", s.getFolder(f.id)?.name)
        assertFalse(s.renameFolder(f.id, "   "))
        assertFalse(s.moveObject(o.id, 999))
    }

    @Test
    fun folderCycleIsRefused() {
        val s = Scene()
        val a = s.addFolder("A")
        val b = s.addFolder("B", a.id)
        assertFalse(s.moveFolder(a.id, b.id))
        assertFalse(s.moveFolder(a.id, a.id))
        assertTrue(s.moveFolder(b.id, null))
        assertNull(s.getFolder(b.id)?.parentId)
    }

    @Test
    fun removeFolderMovesChildrenUp() {
        val s = Scene()
        val a = s.addFolder("A")
        val b = s.addFolder("B", a.id)
        val o = s.add("X", Shape.SPHERE, folderId = b.id)
        assertTrue(s.removeFolder(b.id))
        assertEquals(a.id, s.get(o.id)?.folderId)
        assertTrue(s.removeFolder(a.id))
        assertNull(s.get(o.id)?.folderId)
    }

    @Test
    fun outlinerRowsRespectExpansion() {
        val s = Scene()
        val a = s.addFolder("A")
        s.add("In", Shape.CUBE, folderId = a.id)
        s.add("Out", Shape.CUBE)
        val closed = outlinerRows(s.objects, s.folders, emptySet())
        assertEquals(2, closed.size)
        assertTrue(closed[0] is OutlinerRow.FolderRow)
        val open = outlinerRows(s.objects, s.folders, setOf(a.id))
        assertEquals(3, open.size)
        assertEquals(1, open[1].depth)
    }

    @Test
    fun captureRestoreKeepsFolders() {
        val s = Scene()
        val a = s.addFolder("A")
        val saved = s.capture()
        s.removeFolder(a.id)
        s.restore(saved)
        assertEquals(1, s.folders.size)
    }

    @Test
    fun projectJsonRoundTrip() {
        val s = Scene()
        val f = s.addFolder("Props")
        s.add("Crate", Shape.CUBE, Vec3(1f, 2f, 3f), folderId = f.id)
        val data = ProjectData(
            "Demo",
            listOf(NxScriptFile("main.nx", "say \"hi\"\n"), NxScriptFile("enemy.nx", "# x")),
            1,
            s.capture()
        )
        val back = ProjectFormat.fromJson(ProjectFormat.toJson(data))
        assertEquals("Demo", back.name)
        assertEquals(listOf("main.nx", "enemy.nx"), back.scripts.map { it.name })
        assertEquals("say \"hi\"\n", back.scripts[0].text)
        assertEquals(1, back.activeScript)
        assertEquals(1, back.scene.folders.size)
        assertEquals(Vec3(1f, 2f, 3f), back.scene.objects[0].position)
        assertEquals(f.id, back.scene.objects[0].folderId)
    }

    @Test
    fun badProjectFilesAreRejected() {
        assertFailsWith<ProjectFormatException> { ProjectFormat.fromJson("not json") }
        assertFailsWith<ProjectFormatException> { ProjectFormat.fromJson("{\"name\":\"x\"}") }
        assertFailsWith<ProjectFormatException> { ProjectFormat.fromJson("{\"schema\":99}") }
    }

    @Test
    fun scriptNames() {
        assertEquals("main.nx", ProjectFormat.normalizeScriptName("main"))
        assertEquals("a_b.nx", ProjectFormat.normalizeScriptName("a/b.nx"))
        assertEquals("script.nx", ProjectFormat.normalizeScriptName("  "))
        assertEquals("main 2.nx", ProjectFormat.uniqueScriptName("Main", listOf("main.nx")))
    }
}
