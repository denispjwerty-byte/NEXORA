package forge.core

import nx.NxException
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertTrue

class ScriptHubTest {
    private val scene = Scene()
    private val lines = ArrayList<String>()

    /** Builds a hub; the first file is the entry script. Output lines are recorded as "file: text". */
    private fun hub(vararg files: Pair<String, String>): ScriptHub = ScriptHub(
        scripts = files.map { NxScriptFile(it.first, it.second.trimIndent()) },
        baseModules = GameModule.modules(scene, GameClock()),
        out = { name, text -> lines.add("$name: $text") }
    )

    private fun start(vararg files: Pair<String, String>): ScriptHub {
        val h = hub(*files)
        h.start(files[0].first)
        return h
    }

    private fun failure(block: () -> Unit): NxException {
        try {
            block()
        } catch (e: NxException) {
            return e
        }
        throw AssertionError("expected an NxException")
    }

    // ---------------------------------------------------------------- calls

    @Test
    fun callReturnsValue() {
        start(
            "main.nx" to """
                load scripts
                run startScript "lib"
                say run callScript "lib", "double", 21
            """,
            "lib.nx" to """
                action double x
                    yield x * 2
            """
        )
        assertEquals(listOf("main.nx: 42"), lines)
    }

    @Test
    fun scriptNamesAreCaseInsensitiveAndIgnoreExtension() {
        start(
            "main.nx" to """
                load scripts
                run startScript "LIB.nx"
                say run callScript "lib", "one"
                say run hasScript "Lib"
                say run hasScript "missing"
            """,
            "lib.nx" to """
                action one
                    yield 1
            """
        )
        assertEquals(listOf("main.nx: 1", "main.nx: true", "main.nx: false"), lines)
    }

    @Test
    fun callingANotStartedScriptFails() {
        val e = failure {
            start(
                "main.nx" to """
                    load scripts
                    run callScript "lib", "one"
                """,
                "lib.nx" to """
                    action one
                        yield 1
                """
            )
        }
        assertEquals("NX9041", e.code)
    }

    @Test
    fun unknownScriptAndUnknownAction() {
        val noScript = failure {
            start("main.nx" to "load scripts\nrun startScript \"nothing\"")
        }
        assertEquals("NX9042", noScript.code)

        val noAction = failure {
            start(
                "main.nx" to """
                    load scripts
                    run startScript "lib"
                    run callScript "lib", "missing"
                """,
                "lib.nx" to "say \"hi\""
            )
        }
        assertEquals("NX9043", noAction.code)
    }

    @Test
    fun startingTwiceRunsTheTopLevelOnce() {
        start(
            "main.nx" to """
                load scripts
                run startScript "lib"
                run startScript "lib"
            """,
            "lib.nx" to "say \"lib loaded\""
        )
        assertEquals(listOf("lib.nx: lib loaded"), lines)
    }

    @Test
    fun scriptsCanStartEachOther() {
        start(
            "a.nx" to """
                load scripts
                run startScript "b"
                say "a done"
            """,
            "b.nx" to """
                load scripts
                run startScript "a"
                say "b done"
            """
        )
        assertEquals(listOf("b.nx: b done", "a.nx: a done"), lines)
    }

    @Test
    fun selfNameAndRunningScripts() {
        val h = start(
            "main.nx" to """
                load scripts
                run startScript "lib"
                say run selfName
                say run isRunning "lib"
            """,
            "lib.nx" to """
                load scripts
                say run selfName
            """
        )
        assertEquals(listOf("lib.nx: lib.nx", "main.nx: main.nx", "main.nx: true"), lines)
        assertEquals(listOf("main.nx", "lib.nx"), h.runningScripts)
    }

    @Test
    fun stopScriptStopsItAndDropsItsEvents() {
        val h = start(
            "main.nx" to """
                load scripts
                run startScript "a"
                run stopScript "a"
                say run isRunning "a"
                say run emit "hit", 1
            """,
            "a.nx" to """
                load scripts
                action onHit n
                    say n
                run on "hit", "onHit"
            """
        )
        assertEquals(listOf("main.nx: false", "main.nx: 0"), lines)
        assertEquals(listOf("main.nx"), h.runningScripts)
    }

    @Test
    fun aScriptCannotStopItself() {
        val e = failure {
            start("main.nx" to "load scripts\nrun stopScript \"main\"")
        }
        assertEquals("NX9045", e.code)
    }

    // ---------------------------------------------------------------- messages

    @Test
    fun messagesArriveInOrder() {
        val h = start(
            "main.nx" to """
                load scripts
                run startScript "worker"
                run send "worker", "job", 5
                run send "worker", "stop", 0
            """,
            "worker.nx" to """
                load scripts
                action update
                    repeat while (run inboxCount) > 0
                        data m = run receive
                        say m[0]
                        say m[1]
                        say m[2]
            """
        )
        assertTrue(lines.isEmpty())
        h.update(0.016f)
        assertEquals(
            listOf(
                "worker.nx: main.nx", "worker.nx: job", "worker.nx: 5",
                "worker.nx: main.nx", "worker.nx: stop", "worker.nx: 0"
            ),
            lines
        )
    }

    @Test
    fun sentListsAreCopied() {
        val h = start(
            "main.nx" to """
                load scripts
                run startScript "box"
                data l = [1, 2]
                run send "box", "t", l
                change l[0] = 99
            """,
            "box.nx" to """
                load scripts
                action update
                    data m = run receive
                    data inner = m[2]
                    say inner[0]
            """
        )
        h.update(0.016f)
        assertEquals(listOf("box.nx: 1"), lines)
    }

    @Test
    fun receiveOnEmptyInboxIsARecoverableError() {
        start(
            "main.nx" to """
                load scripts
                attempt
                    data m = run receive
                recover
                    say "empty"
            """
        )
        assertEquals(listOf("main.nx: empty"), lines)
    }

    @Test
    fun inboxIsLimited() {
        val e = failure {
            start(
                "main.nx" to """
                    load scripts
                    repeat 1001
                        run send "main", "t", 0
                """
            )
        }
        assertEquals("NX9047", e.code)
    }

    // ---------------------------------------------------------------- events

    @Test
    fun emitCallsEverySubscriberAndCountsThem() {
        start(
            "main.nx" to """
                load scripts
                run startScript "a"
                data c = run emit "hit", 3
                say c
                run emit "hit", 4
                say run emit "nobody"
            """,
            "a.nx" to """
                load scripts
                data hits = 0
                action onHit n
                    change hits = hits + n
                    say hits
                run on "hit", "onHit"
            """
        )
        assertEquals(listOf("a.nx: 3", "main.nx: 1", "a.nx: 7", "main.nx: 0"), lines)
    }

    @Test
    fun offRemovesTheSubscription() {
        start(
            "main.nx" to """
                load scripts
                action onPing
                    say "ping"
                run on "ping", "onPing"
                run emit "ping"
                run off "ping"
                run emit "ping"
            """
        )
        assertEquals(listOf("main.nx: ping"), lines)
    }

    @Test
    fun subscribingToAnUnknownActionFails() {
        val e = failure {
            start("main.nx" to "load scripts\nrun on \"x\", \"nothing\"")
        }
        assertEquals("NX9043", e.code)
    }

    // ---------------------------------------------------------------- shared data

    @Test
    fun sharedDataIsVisibleToOtherScripts() {
        start(
            "main.nx" to """
                load scripts
                run share "score", 10
                run startScript "lib"
                say run hasShared "nope"
                run unshare "score"
                say run hasShared "score"
            """,
            "lib.nx" to """
                load scripts
                say run shared "score"
            """
        )
        assertEquals(listOf("lib.nx: 10", "main.nx: false", "main.nx: false"), lines)
    }

    @Test
    fun missingSharedValueIsARecoverableError() {
        start(
            "main.nx" to """
                load scripts
                attempt
                    say run shared "x"
                recover
                    say "none"
            """
        )
        assertEquals(listOf("main.nx: none"), lines)
    }

    @Test
    fun scriptsShareTheSameScene() {
        start(
            "main.nx" to """
                load game
                load scripts
                data id = run spawn "A", "cube", 0, 0, 0
                run share "id", id
                run startScript "mover"
            """,
            "mover.nx" to """
                load game
                load scripts
                data id = run shared "id"
                run setPos id, 5, 0, 0
            """
        )
        assertEquals(Vec3(5f, 0f, 0f), scene.objects.single().position)
    }

    // ---------------------------------------------------------------- frames and errors

    @Test
    fun updateRunsEveryScriptInStartOrder() {
        val h = start(
            "main.nx" to """
                load scripts
                run startScript "b"
                action update dt
                    say dt
            """,
            "b.nx" to """
                action update
                    say "b"
            """
        )
        h.update(0.5f)
        assertEquals(listOf("main.nx: 0.5", "b.nx: b"), lines)
    }

    @Test
    fun errorsInOtherScriptsNameTheScriptAndKeepTheCode() {
        val e = failure {
            start(
                "main.nx" to """
                    load scripts
                    run startScript "lib"
                    run callScript "lib", "boom"
                """,
                "lib.nx" to """
                    action boom
                        say 1 / 0
                """
            )
        }
        assertEquals("NX9001", e.code)
        assertTrue(e.message.contains("in script 'lib.nx'"))
    }

    @Test
    fun errorInTheEntryScriptHasNoScriptPrefix() {
        val e = failure { start("main.nx" to "say 1 / 0") }
        assertEquals("NX9001", e.code)
        assertFalse(e.message.contains("in script"))
    }

    @Test
    fun failedStartCanBeRecoveredAndLeavesTheScriptStopped() {
        start(
            "main.nx" to """
                load scripts
                attempt
                    run startScript "lib"
                recover
                    say run isRunning "lib"
            """,
            "lib.nx" to "say 1 / 0"
        )
        assertEquals(listOf("main.nx: false"), lines)
    }

    @Test
    fun endlessCrossScriptRecursionIsStopped() {
        val e = failure {
            start(
                "main.nx" to """
                    load scripts
                    run startScript "a"
                    run callScript "a", "ping"
                """,
                "a.nx" to """
                    load scripts
                    action ping
                        run callScript "a", "ping"
                """
            )
        }
        assertEquals("NX9040", e.code)
    }
}
