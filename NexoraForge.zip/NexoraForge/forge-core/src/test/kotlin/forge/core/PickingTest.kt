package forge.core

import kotlin.math.abs
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotNull
import kotlin.test.assertNull
import kotlin.test.assertTrue

class PickingTest {
    private fun cam() = OrbitCamera().apply { yaw = 0f; pitch = 0f; distance = 10f }

    private fun obj(id: Int, shape: Shape, pos: Vec3, rot: Vec3 = Vec3.ZERO, scale: Vec3 = Vec3.ONE) =
        SceneObject(id, "o$id", shape, pos, rot, scale, Vec3.ONE)

    private fun near(a: Float, b: Float, eps: Float = 1e-3f) = abs(a - b) < eps

    private fun through(c: OrbitCamera, p: Vec3): Ray {
        val e = CameraMath.eye(c)
        return Ray(e, (p - e).normalized())
    }

    @Test
    fun centerRayLooksAtTarget() {
        val r = CameraMath.ray(cam(), 200f, 100f, 400f, 200f)
        assertTrue(near(r.dir.x, 0f) && near(r.dir.y, 0f) && near(r.dir.z, -1f))
        val right = CameraMath.ray(cam(), 400f, 100f, 400f, 200f)
        assertTrue(right.dir.x > 0f)
        val top = CameraMath.ray(cam(), 200f, 0f, 400f, 200f)
        assertTrue(top.dir.y > 0f)
    }

    @Test
    fun pickNearestAndMiss() {
        val c = cam()
        val front = obj(1, Shape.CUBE, Vec3(0f, 0.5f, 2f))
        val back = obj(2, Shape.CUBE, Vec3(0f, 0.5f, 0f))
        val ray = CameraMath.ray(c, 200f, 100f, 400f, 200f)
        assertEquals(1, Picking.pick(ray, listOf(back, front)))
        assertNull(Picking.pick(ray, listOf(obj(3, Shape.CUBE, Vec3(5f, 0.5f, 0f)))))
        assertEquals(2, Picking.pick(ray, listOf(back, obj(4, Shape.SPHERE, Vec3(3f, 0.5f, 0f)))))
    }

    @Test
    fun pickRespectsScaleAndRotation() {
        val c = cam()
        val ray = through(c, Vec3(0.9f, 0.5f, 0f))
        // 1-unit cube does not reach x=0.9, a 3-wide cube does
        assertNull(Picking.pick(ray, listOf(obj(1, Shape.CUBE, Vec3(0f, 0.5f, 0f)))))
        assertEquals(2, Picking.pick(ray, listOf(obj(2, Shape.CUBE, Vec3(0f, 0.5f, 0f), scale = Vec3(3f, 1f, 1f)))))
        // a long box turned 90 degrees around Y no longer reaches x=0.9 from the front
        val turned = obj(3, Shape.CUBE, Vec3(0f, 0.5f, 0f), rot = Vec3(0f, 90f, 0f), scale = Vec3(3f, 1f, 0.2f))
        assertNull(Picking.pick(ray, listOf(turned)))
    }

    @Test
    fun moveHandleHitAndDrag() {
        val c = cam()
        val o = obj(1, Shape.CUBE, Vec3(0f, 0.5f, 0f))
        val size = 2f
        val grab = through(c, Vec3(1f, 0.5f, 0f))
        assertEquals(Axis.X, GizmoMath.hitHandle(GizmoMode.MOVE, grab, o.position, size))
        val drag = assertNotNull(GizmoDrag.begin(GizmoMode.MOVE, Axis.X, o, grab))
        val moved = drag.update(through(c, Vec3(2f, 0.5f, 0f)))
        assertTrue(near(moved.position.x, 1f))
        assertTrue(near(moved.position.y, 0.5f) && near(moved.position.z, 0f))
    }

    @Test
    fun handleMissFarFromAxes() {
        val c = cam()
        val ray = through(c, Vec3(1f, 2.5f, 0f))
        assertNull(GizmoMath.hitHandle(GizmoMode.MOVE, ray, Vec3(0f, 0.5f, 0f), 2f))
    }

    @Test
    fun scaleDragIsProportional() {
        val c = cam()
        val o = obj(1, Shape.CUBE, Vec3(0f, 0.5f, 0f), scale = Vec3(2f, 1f, 1f))
        val drag = assertNotNull(GizmoDrag.begin(GizmoMode.SCALE, Axis.X, o, through(c, Vec3(1f, 0.5f, 0f))))
        val r = drag.update(through(c, Vec3(2f, 0.5f, 0f)))
        assertTrue(near(r.scale.x, 4f))
        assertTrue(near(r.scale.y, 1f))
        val tiny = drag.update(through(c, Vec3(-3f, 0.5f, 0f)))
        assertTrue(tiny.scale.x >= 0.01f)
    }

    @Test
    fun rotateDragFollowsPointer() {
        val o = obj(1, Shape.CUBE, Vec3(0f, 0.5f, 0f))
        val down = Vec3(0f, -1f, 0f)
        val drag = assertNotNull(GizmoDrag.begin(GizmoMode.ROTATE, Axis.Y, o, Ray(Vec3(1f, 10f, 0f), down)))
        val r = drag.update(Ray(Vec3(0f, 10f, 1f), down))
        assertTrue(near(r.rotation.y, -90f, 0.05f))
        assertTrue(near(r.rotation.x, 0f) && near(r.rotation.z, 0f))
    }
}
