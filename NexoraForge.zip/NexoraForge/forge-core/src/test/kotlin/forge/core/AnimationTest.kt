package forge.core

import kotlin.math.abs
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertNotNull
import kotlin.test.assertTrue

class AnimationTest {
    private fun near(a: Float, b: Float, eps: Float = 1e-3f) = abs(a - b) < eps

    private fun cube(id: Int = 1, x: Float = 0f) =
        SceneObject(id, "c", Shape.CUBE, Vec3(x, 0f, 0f), Vec3.ZERO, Vec3.ONE, Vec3.ONE)

    private fun clipMoveX(action: String = "jump", loop: Boolean = false) =
        Anim.setKey(Anim.setKey(AnimClip(1, "Jump", action, 1f, loop), cube(x = 0f), 0f), cube(x = 10f), 1f)

    @Test
    fun setKeyKeepsOrderAndReplacesSameTime() {
        var c = AnimClip(1, "a", duration = 2f)
        c = Anim.setKey(c, cube(x = 5f), 1f)
        c = Anim.setKey(c, cube(x = 1f), 0f)
        c = Anim.setKey(c, cube(x = 9f), 1.005f)
        val keys = assertNotNull(Anim.track(c, 1)).keys
        assertEquals(2, keys.size)
        assertTrue(keys[0].time < keys[1].time)
        assertTrue(near(keys[1].position.x, 9f))
        assertTrue(Anim.hasKeyAt(c, 1, 1f))
    }

    @Test
    fun removeKeyDropsEmptyTrack() {
        var c = Anim.setKey(AnimClip(1, "a"), cube(), 0.5f)
        c = Anim.removeKey(c, 1, 0.5f)
        assertTrue(c.tracks.isEmpty())
    }

    @Test
    fun sampleInterpolatesAndHolds() {
        val tr = assertNotNull(Anim.track(clipMoveX(), 1))
        assertTrue(near(assertNotNull(Anim.sample(tr, 0.5f)).position.x, 5f))
        assertTrue(near(assertNotNull(Anim.sample(tr, -1f)).position.x, 0f))
        assertTrue(near(assertNotNull(Anim.sample(tr, 5f)).position.x, 10f))
    }

    @Test
    fun durationNeverCutsKeys() {
        val c = Anim.withDuration(clipMoveX(), 0.2f)
        assertTrue(near(c.duration, 1f))
        assertTrue(near(Anim.withDuration(AnimClip(1, "a"), 0f).duration, Anim.MIN_DURATION))
    }

    @Test
    fun playerRunsClipForBoundActionOnly() {
        val scene = Scene()
        val o = scene.add("c", Shape.CUBE)
        val clip = Anim.setKey(Anim.setKey(AnimClip(1, "J", "jump", 1f), o, 0f), o.copy(position = Vec3(10f, 0f, 0f)), 1f)
        val player = AnimationPlayer(scene)
        assertEquals(0, player.trigger("other", listOf(clip)))
        assertEquals(0, player.activeCount)
        assertEquals(1, player.trigger("jump", listOf(clip)))
        player.advance(0.5f)
        assertTrue(near(scene.get(o.id)!!.position.x, 5f))
        player.advance(0.6f)
        assertTrue(near(scene.get(o.id)!!.position.x, 10f))
        assertEquals(0, player.activeCount)
    }

    @Test
    fun loopingClipKeepsPlayingAndRestartResets() {
        val scene = Scene()
        val o = scene.add("c", Shape.CUBE)
        val clip = Anim.setKey(Anim.setKey(AnimClip(1, "L", "spin", 1f, loop = true), o, 0f), o.copy(position = Vec3(10f, 0f, 0f)), 1f)
        val player = AnimationPlayer(scene)
        player.trigger("spin", listOf(clip))
        player.advance(1.25f)
        assertEquals(1, player.activeCount)
        assertTrue(near(scene.get(o.id)!!.position.x, 2.5f))
        player.trigger("spin", listOf(clip))
        assertEquals(1, player.activeCount)
        assertTrue(near(scene.get(o.id)!!.position.x, 0f))
        player.stopAll()
        assertEquals(0, player.activeCount)
    }

    @Test
    fun playerSkipsDeletedObjects() {
        val scene = Scene()
        val clip = clipMoveX()
        val player = AnimationPlayer(scene)
        player.trigger("jump", listOf(clip))
        player.advance(0.5f)
        assertEquals(0, scene.objects.size)
    }

    @Test
    fun actionNamesAndDetection() {
        assertEquals("jump", Anim.normalizeAction("  action jump "))
        assertTrue(Anim.isValidAction(""))
        assertTrue(Anim.isValidAction("jump_2"))
        assertFalse(Anim.isValidAction("2jump"))
        assertFalse(Anim.isValidAction("a b"))
        val scripts = listOf(NxScriptFile("main.nx", "# action fake\naction jump\n    say \"x\"\naction jumpHigh a\n    say a\n"))
        assertTrue(Anim.declaresAction(scripts, "jump"))
        assertTrue(Anim.declaresAction(scripts, "jumpHigh"))
        assertFalse(Anim.declaresAction(scripts, "fake"))
        assertFalse(Anim.declaresAction(scripts, "jum"))
        assertFalse(Anim.declaresAction(scripts, ""))
    }

    @Test
    fun restPoseReplacesAnimatedTransforms() {
        val s = Scene()
        val a = s.add("a", Shape.CUBE)
        val b = s.add("b", Shape.CUBE)
        val base = s.capture()
        s.update(a.id) { it.copy(position = Vec3(7f, 0f, 0f)) }
        s.update(b.id) { it.copy(position = Vec3(8f, 0f, 0f)) }
        val saved = Anim.withRest(s.capture(), base, setOf(a.id))
        assertTrue(near(saved.objects.first { it.id == a.id }.position.x, 0f))
        assertTrue(near(saved.objects.first { it.id == b.id }.position.x, 8f))
    }

    @Test
    fun clipsSurviveProjectJson() {
        val s = Scene()
        val clip = clipMoveX("jump", loop = true)
        val data = ProjectData("P", listOf(NxScriptFile("main.nx", "")), 0, s.capture(), listOf(clip))
        val back = ProjectFormat.fromJson(ProjectFormat.toJson(data))
        assertEquals(1, back.clips.size)
        val c = back.clips[0]
        assertEquals("jump", c.action)
        assertTrue(c.loop)
        assertTrue(near(c.duration, 1f))
        assertEquals(2, assertNotNull(Anim.track(c, 1)).keys.size)
    }

    @Test
    fun oldProjectWithoutAnimationsStillLoads() {
        val json = "{\"schema\":1,\"name\":\"Old\",\"scripts\":[],\"scene\":{}}"
        assertTrue(ProjectFormat.fromJson(json).clips.isEmpty())
    }
}
