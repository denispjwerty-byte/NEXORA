package forge.core

import nx.Nx
import nx.NxException
import nx.NxInterpreter
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotNull
import kotlin.test.assertNull
import kotlin.test.assertTrue

class GameModuleTest {
    private val scene = Scene()
    private val clock = GameClock()
    private val lines = ArrayList<String>()

    private fun interp() = NxInterpreter(
        out = { lines.add(it) },
        modules = GameModule.modules(scene, clock)
    )

    @Test
    fun spawnAndMove() {
        val i = interp()
        i.run(
            Nx.parse(
                """
                load game
                data id = run spawn "A", "cube", 1, 2, 3
                run setPos id, 4, 5.5, 6
                run setColor id, 2.0, 0.5, -1.0
                say run getX id
                """.trimIndent()
            )
        )
        val o = scene.objects.single()
        assertEquals(Vec3(4f, 5.5f, 6f), o.position)
        assertEquals(Vec3(1f, 0.5f, 0f), o.color)
        assertEquals(listOf("4.0"), lines)
    }

    @Test
    fun destroyAndErrors() {
        val i = interp()
        i.run(
            Nx.parse(
                """
                load game
                data id = run spawn "A", "sphere", 0, 0, 0
                run destroy id
                attempt
                    run destroy id
                recover
                    say "gone"
                """.trimIndent()
            )
        )
        assertTrue(scene.objects.isEmpty())
        assertEquals(listOf("gone"), lines)
    }

    @Test
    fun badShapeIsRuntimeError() {
        val i = interp()
        val e = runCatching {
            i.run(Nx.parse("load game\nrun spawn \"A\", \"teapot\", 0, 0, 0"))
        }.exceptionOrNull()
        assertTrue(e is NxException)
        assertEquals("NX9030", (e as NxException).code)
    }

    @Test
    fun updateHookUsesClock() {
        val i = interp()
        i.run(
            Nx.parse(
                """
                load game
                data id = run spawn "A", "cube", 0, 0, 0
                action update dt
                    run setPos id, run elapsed, 0, 0
                """.trimIndent()
            )
        )
        assertTrue(i.hasAction("update"))
        assertEquals(1, i.actionArity("update"))
        clock.advance(2f)
        i.callAction("update", listOf(2.0))
        assertEquals(2f, scene.objects.single().position.x)
    }

    @Test
    fun captureAndRestore() {
        scene.add("keep", Shape.CUBE)
        val state = scene.capture()
        scene.add("temp", Shape.SPHERE)
        assertEquals(2, scene.objects.size)
        scene.restore(state)
        assertEquals(1, scene.objects.size)
        assertNotNull(scene.get(1))
        assertNull(scene.get(2))
        assertEquals(2, scene.add("again", Shape.PLANE).id)
    }
}
