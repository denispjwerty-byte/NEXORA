plugins {
    id("org.jetbrains.kotlin.jvm")
}

kotlin {
    jvmToolchain(17)
}

dependencies {
    implementation(project(":nx-lang"))
    testImplementation(kotlin("test"))
}

tasks.test {
    useJUnitPlatform()
}
