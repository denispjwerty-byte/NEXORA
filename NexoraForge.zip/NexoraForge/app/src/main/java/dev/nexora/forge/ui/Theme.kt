package dev.nexora.forge.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object ForgeColors {
    val Bg = Color(0xFF0E1220)
    val TopBar = Color(0xFF121729)
    val Panel = Color(0xFF161B2E)
    val Row = Color(0xFF1E2540)
    val Accent = Color(0xFF8B7CFF)
    val Cyan = Color(0xFF4FC3F7)
    val Muted = Color(0xFF8E97B8)
    val Text = Color(0xFFE6E9F7)
    val Error = Color(0xFFFF6B6B)
    val Stop = Color(0xFFE05555)
}

@Composable
fun NexoraTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = ForgeColors.Accent,
            secondary = ForgeColors.Cyan,
            background = ForgeColors.Bg,
            surface = ForgeColors.Panel,
            onBackground = ForgeColors.Text,
            onSurface = ForgeColors.Text,
            onPrimary = Color.White,
            error = ForgeColors.Error
        ),
        content = content
    )
}
