package dev.nexora.forge.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.runtime.withFrameNanos
import dev.nexora.forge.editor.EditorViewModel
import dev.nexora.forge.viewport.GlViewport
import forge.core.GizmoMode

/** Full-screen game: only the 3D view, the script output and an Exit button. */
@Composable
fun GameScreen(vm: EditorViewModel) {
    BackHandler { vm.exitGame() }

    // Same frame loop as in the editor: calls the NX `update` action once per frame.
    LaunchedEffect(vm.playing) {
        if (vm.playing) {
            var last = 0L
            while (true) {
                withFrameNanos { now ->
                    if (last != 0L) vm.tick(((now - last) / 1_000_000_000f).coerceAtMost(0.1f))
                    last = now
                }
            }
        }
    }

    Surface(color = MaterialTheme.colorScheme.background, modifier = Modifier.fillMaxSize()) {
        Box(Modifier.fillMaxSize()) {
            GlViewport(
                scene = vm.scene,
                camera = vm.camera,
                selectedId = null,
                gizmoMode = GizmoMode.MOVE,
                onPick = {},
                onObjectChange = { _, _ -> },
                modifier = Modifier.fillMaxSize()
            )
            Button(
                onClick = { vm.exitGame() },
                modifier = Modifier.align(Alignment.TopEnd).padding(8.dp)
            ) { Text("Exit") }

            // Script output (`say`) and errors, so a failing game is not a silent black screen.
            Column(Modifier.align(Alignment.BottomStart).padding(8.dp)) {
                if (!vm.playing) {
                    Text("Game is not running", color = ForgeColors.Muted, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
                for (line in vm.console.takeLast(6)) {
                    Text(
                        line.text,
                        color = if (line.isError) ForgeColors.Error else ForgeColors.Text,
                        fontSize = 12.sp
                    )
                }
            }
        }
    }
}
