package dev.nexora.forge.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.nexora.forge.editor.EditorViewModel
import forge.core.Anim
import java.util.Locale
import kotlin.math.abs
import kotlin.math.floor

@Composable
fun AnimationPanel(vm: EditorViewModel) {
    var newClip by remember { mutableStateOf(false) }
    var rename by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    val clip = vm.currentClip()

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            vm.clips.forEachIndexed { i, c ->
                Text(
                    c.name,
                    color = ForgeColors.Text,
                    fontSize = 13.sp,
                    maxLines = 1,
                    modifier = Modifier
                        .background(if (i == vm.activeClip) ForgeColors.Accent.copy(alpha = 0.45f) else ForgeColors.Row)
                        .clickable { vm.selectClip(i) }
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                )
            }
            TextButton(onClick = { newClip = true }) { Text("+ new") }
        }

        if (clip == null) {
            Text("No animations yet. Tap \"+ new\".", color = ForgeColors.Muted, modifier = Modifier.padding(top = 8.dp))
        } else {
            Row {
                TextButton(onClick = { rename = true }) { Text("Rename") }
                TextButton(onClick = { confirmDelete = true }) { Text("Delete", color = ForgeColors.Error) }
            }

            var actionText by remember(clip.id) { mutableStateOf(clip.action) }
            val actionValid = Anim.isValidAction(Anim.normalizeAction(actionText))
            OutlinedTextField(
                value = actionText,
                onValueChange = {
                    actionText = it
                    vm.setClipAction(it)
                },
                label = { Text("Script action that starts this animation") },
                isError = !actionValid,
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            val bound = Anim.normalizeAction(actionText)
            val hint: String
            var hintColor = ForgeColors.Muted
            if (!actionValid) {
                hint = "Not a valid action name (letters, digits, _; must not start with a digit)."
                hintColor = ForgeColors.Error
            } else if (bound.isEmpty()) {
                hint = "Not bound: the animation only plays from the editor preview."
            } else if (vm.actionDeclared(bound)) {
                hint = "Plays when the script runs: run $bound"
            } else {
                hint = "No \"action $bound\" found in the scripts yet. Add it, then use: run $bound"
                hintColor = ForgeColors.Error
            }
            Text(hint, color = hintColor, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp))

            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 8.dp)) {
                DurationField(clip.id, clip.duration) { vm.setClipDuration(it) }
                Spacer(Modifier.padding(start = 12.dp))
                Text("Loop", color = ForgeColors.Text)
                Spacer(Modifier.padding(start = 8.dp))
                Switch(checked = clip.loop, onCheckedChange = { vm.setClipLoop(it) })
            }

            val sel = remember(vm.sceneVersion, vm.selectedId) { vm.selectedObject() }
            val keys = if (sel == null) emptyList() else (Anim.track(clip, sel.id)?.keys ?: emptyList()).map { it.time }
            Text(
                "Object: " + (sel?.name ?: "none (select one in Outliner or tap it)"),
                color = ForgeColors.Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp)
            )
            Timeline(clip.duration, keys, vm.animTime) { vm.setAnimTime(it) }
            Text(
                String.format(Locale.US, "t = %.2f / %.2f s", vm.animTime, clip.duration),
                color = ForgeColors.Text, fontSize = 13.sp
            )
            val hasKey = sel != null && Anim.hasKeyAt(clip, sel.id, vm.animTime)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(top = 6.dp)) {
                Button(onClick = { vm.addKey() }, enabled = sel != null) { Text(if (hasKey) "Update key" else "Add key") }
                FilledTonalButton(onClick = { vm.removeKey() }, enabled = hasKey) { Text("Delete key") }
                FilledTonalButton(onClick = { vm.togglePreview() }) { Text(if (vm.previewing) "Pause" else "Preview") }
            }
            Text(
                "Pose the object with the gizmo at some time, then tap Add key. " +
                    "Leaving Animate mode puts animated objects back to their rest pose.",
                color = ForgeColors.Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp)
            )
        }
    }

    if (newClip) {
        TextInputDialog("New animation", "Animation", "Create", { vm.addClip(it) }, { newClip = false })
    }
    if (rename && clip != null) {
        TextInputDialog("Rename animation", clip.name, "Rename", { vm.renameClip(it) }, { rename = false })
    }
    if (confirmDelete && clip != null) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Delete \"${clip.name}\"?") },
            text = { Text("All its keyframes will be lost.") },
            confirmButton = {
                TextButton(onClick = { vm.deleteClip(); confirmDelete = false }) { Text("Delete", color = ForgeColors.Error) }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun DurationField(clipId: Int, duration: Float, onValue: (Float) -> Unit) {
    fun fmt(v: Float) = String.format(Locale.US, "%.2f", v).trimEnd('0').trimEnd('.')
    var text by remember(clipId) { mutableStateOf(fmt(duration)) }
    LaunchedEffect(duration) {
        if (text.replace(',', '.').toFloatOrNull() != duration) text = fmt(duration)
    }
    OutlinedTextField(
        value = text,
        onValueChange = { t ->
            text = t
            t.replace(',', '.').toFloatOrNull()?.let(onValue)
        },
        label = { Text("Seconds") },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        modifier = Modifier.padding(end = 0.dp).fillMaxWidth(0.4f)
    )
}

/** Timeline with one diamond per keyframe of the selected object. Tap or drag to move the cursor. */
@Composable
private fun Timeline(duration: Float, keys: List<Float>, time: Float, onSeek: (Float) -> Unit) {
    val padPx = with(LocalDensity.current) { 16.dp.toPx() }
    val snapPx = with(LocalDensity.current) { 14.dp.toPx() }
    val diamond = with(LocalDensity.current) { 9.dp.toPx() }
    val seek by rememberUpdatedState(onSeek)

    fun toTime(x: Float, width: Int): Float {
        val usable = (width - 2 * padPx).coerceAtLeast(1f)
        return ((x - padPx) / usable).coerceIn(0f, 1f) * duration
    }

    Canvas(
        Modifier
            .fillMaxWidth()
            .height(56.dp)
            .background(ForgeColors.Row)
            .pointerInput(duration, keys) {
                detectTapGestures { o ->
                    val usable = (size.width - 2 * padPx).coerceAtLeast(1f)
                    val near = keys.minByOrNull { abs(padPx + it / duration * usable - o.x) }
                    val snapped = near != null && abs(padPx + near / duration * usable - o.x) < snapPx
                    seek(if (snapped && near != null) near else toTime(o.x, size.width))
                }
            }
            .pointerInput(duration) {
                detectHorizontalDragGestures { change, _ -> seek(toTime(change.position.x, size.width)) }
            }
    ) {
        val usable = (size.width - 2 * padPx).coerceAtLeast(1f)
        val cy = size.height / 2f
        drawLine(ForgeColors.Muted, Offset(padPx, cy), Offset(padPx + usable, cy), 2f)
        for (i in 0..floor(duration).toInt()) {
            val x = padPx + i / duration * usable
            drawLine(ForgeColors.Muted, Offset(x, cy - 6f), Offset(x, cy + 6f), 2f)
        }
        for (k in keys) {
            val x = padPx + k / duration * usable
            val atCursor = abs(k - time) < Anim.KEY_EPS
            val path = Path().apply {
                moveTo(x, cy - diamond)
                lineTo(x + diamond, cy)
                lineTo(x, cy + diamond)
                lineTo(x - diamond, cy)
                close()
            }
            drawPath(path, if (atCursor) ForgeColors.Cyan else ForgeColors.Accent)
        }
        val px = padPx + (time / duration).coerceIn(0f, 1f) * usable
        drawLine(ForgeColors.Cyan, Offset(px, 0f), Offset(px, size.height), 3f)
    }
}
