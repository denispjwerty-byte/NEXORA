package dev.nexora.forge.viewport

import android.annotation.SuppressLint
import android.content.Context
import android.opengl.GLSurfaceView
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.ViewConfiguration
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import forge.core.CameraMath
import forge.core.GizmoDrag
import forge.core.GizmoMath
import forge.core.GizmoMode
import forge.core.OrbitCamera
import forge.core.Picking
import forge.core.Scene
import forge.core.SceneObject

class ForgeGLView(
    context: Context,
    private val renderer: ForgeRenderer,
    private val camera: OrbitCamera,
    private val scene: Scene
) : GLSurfaceView(context) {

    /** Set by the Compose wrapper on every recomposition. */
    var onPick: (Int?) -> Unit = {}
    var onObjectChange: (Int, (SceneObject) -> SceneObject) -> Unit = { _, _ -> }

    private val scaleDetector = ScaleGestureDetector(
        context,
        object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                camera.zoom(detector.scaleFactor)
                return true
            }
        }
    )
    private val slop = ViewConfiguration.get(context).scaledTouchSlop.toFloat()
    private var lastX = 0f
    private var lastY = 0f
    private var downX = 0f
    private var downY = 0f
    private var moved = false
    private var multi = false
    private var drag: GizmoDrag? = null
    private var dragId = -1

    init {
        setEGLContextClientVersion(2)
        preserveEGLContextOnPause = true
        setRenderer(renderer)
        renderMode = RENDERMODE_CONTINUOUSLY
    }

    private fun rayAt(x: Float, y: Float) =
        CameraMath.ray(camera, x, y, width.toFloat().coerceAtLeast(1f), height.toFloat().coerceAtLeast(1f))

    private fun endDrag() {
        drag = null
        dragId = -1
        renderer.activeAxis = null
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(e: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX = e.x
                lastY = e.y
                downX = e.x
                downY = e.y
                moved = false
                multi = false
                endDrag()
                // Grab a gizmo handle of the selected object, if the touch lands on one.
                val sel = scene.get(renderer.selectedId)
                if (sel != null) {
                    val ray = rayAt(e.x, e.y)
                    val size = GizmoMath.size(CameraMath.eye(camera), sel.position)
                    val axis = GizmoMath.hitHandle(renderer.gizmoMode, ray, sel.position, size)
                    if (axis != null) {
                        val d = GizmoDrag.begin(renderer.gizmoMode, axis, sel, ray)
                        if (d != null) {
                            drag = d
                            dragId = sel.id
                            renderer.activeAxis = axis
                            parent?.requestDisallowInterceptTouchEvent(true)
                        }
                    }
                }
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                multi = true
                if (drag != null) endDrag()
            }
            MotionEvent.ACTION_MOVE -> {
                val d = drag
                if (d != null && e.pointerCount == 1) {
                    val updated = d.update(rayAt(e.x, e.y))
                    onObjectChange(dragId) {
                        it.copy(position = updated.position, rotation = updated.rotation, scale = updated.scale)
                    }
                } else if (e.pointerCount == 1 && !scaleDetector.isInProgress) {
                    if (Math.abs(e.x - downX) > slop || Math.abs(e.y - downY) > slop) moved = true
                    camera.orbit(e.x - lastX, e.y - lastY)
                    lastX = e.x
                    lastY = e.y
                }
            }
            MotionEvent.ACTION_POINTER_UP -> {
                val remaining = if (e.actionIndex == 0) 1 else 0
                lastX = e.getX(remaining)
                lastY = e.getY(remaining)
            }
            MotionEvent.ACTION_UP -> {
                if (drag != null) {
                    endDrag()
                } else if (!moved && !multi) {
                    onPick(Picking.pick(rayAt(e.x, e.y), scene.objects))
                }
            }
            MotionEvent.ACTION_CANCEL -> endDrag()
        }
        return true
    }
}

@Composable
fun GlViewport(
    scene: Scene,
    camera: OrbitCamera,
    selectedId: Int?,
    gizmoMode: GizmoMode,
    onPick: (Int?) -> Unit,
    onObjectChange: (Int, (SceneObject) -> SceneObject) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val renderer = remember { ForgeRenderer(scene, camera) }
    renderer.selectedId = selectedId ?: -1
    renderer.gizmoMode = gizmoMode
    val glView = remember { ForgeGLView(context, renderer, camera, scene) }
    glView.onPick = onPick
    glView.onObjectChange = onObjectChange

    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner, glView) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) glView.onResume()
            if (event == Lifecycle.Event.ON_PAUSE) glView.onPause()
        }
        owner.lifecycle.addObserver(observer)
        onDispose { owner.lifecycle.removeObserver(observer) }
    }

    AndroidView(factory = { glView }, modifier = modifier)
}
