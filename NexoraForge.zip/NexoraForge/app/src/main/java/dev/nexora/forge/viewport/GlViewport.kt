package dev.nexora.forge.viewport

import android.annotation.SuppressLint
import android.content.Context
import android.opengl.GLSurfaceView
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import forge.core.OrbitCamera
import forge.core.Scene

class ForgeGLView(
    context: Context,
    renderer: ForgeRenderer,
    private val camera: OrbitCamera
) : GLSurfaceView(context) {

    private val scaleDetector = ScaleGestureDetector(
        context,
        object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                camera.zoom(detector.scaleFactor)
                return true
            }
        }
    )
    private var lastX = 0f
    private var lastY = 0f

    init {
        setEGLContextClientVersion(2)
        preserveEGLContextOnPause = true
        setRenderer(renderer)
        renderMode = RENDERMODE_CONTINUOUSLY
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(e: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX = e.x
                lastY = e.y
            }
            MotionEvent.ACTION_MOVE -> {
                if (e.pointerCount == 1 && !scaleDetector.isInProgress) {
                    camera.orbit(e.x - lastX, e.y - lastY)
                    lastX = e.x
                    lastY = e.y
                }
            }
            MotionEvent.ACTION_POINTER_UP -> {
                val remaining = if (e.actionIndex == 0) 1 else 0
                lastX = e.getX(remaining)
                lastY = e.getY(remaining)
            }
        }
        return true
    }
}

@Composable
fun GlViewport(scene: Scene, camera: OrbitCamera, selectedId: Int?, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val renderer = remember { ForgeRenderer(scene, camera) }
    renderer.selectedId = selectedId ?: -1
    val glView = remember { ForgeGLView(context, renderer, camera) }

    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner, glView) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) glView.onResume()
            if (event == Lifecycle.Event.ON_PAUSE) glView.onPause()
        }
        owner.lifecycle.addObserver(observer)
        onDispose { owner.lifecycle.removeObserver(observer) }
    }

    AndroidView(factory = { glView }, modifier = modifier)
}
