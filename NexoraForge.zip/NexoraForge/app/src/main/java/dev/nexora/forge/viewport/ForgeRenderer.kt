package dev.nexora.forge.viewport

import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import forge.core.OrbitCamera
import forge.core.Scene
import forge.core.Shape
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.nio.ShortBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.cos
import kotlin.math.sin

private const val VERTEX_SRC = """
uniform mat4 uMvp;
uniform mat4 uModel;
attribute vec3 aPos;
attribute vec3 aNormal;
varying vec3 vN;
void main() {
    vN = mat3(uModel) * aNormal;
    gl_Position = uMvp * vec4(aPos, 1.0);
}
"""

private const val FRAGMENT_SRC = """
precision mediump float;
uniform vec4 uColor;
uniform float uLit;
varying vec3 vN;
void main() {
    vec3 c = uColor.rgb;
    if (uLit > 0.5) {
        vec3 n = normalize(vN);
        vec3 l = normalize(vec3(0.4, 0.9, 0.5));
        float d = max(dot(n, l), 0.0);
        c = c * (0.35 + 0.65 * d);
    }
    gl_FragColor = vec4(c, uColor.a);
}
"""

private class GpuMesh(data: MeshData) {
    private val vb: FloatBuffer = ByteBuffer.allocateDirect(data.vertices.size * 4)
        .order(ByteOrder.nativeOrder()).asFloatBuffer().apply {
            put(data.vertices)
            position(0)
        }
    private val ib: ShortBuffer = ByteBuffer.allocateDirect(data.indices.size * 2)
        .order(ByteOrder.nativeOrder()).asShortBuffer().apply {
            put(data.indices)
            position(0)
        }
    private val count = data.indices.size

    fun draw(aPos: Int, aNormal: Int) {
        vb.position(0)
        GLES20.glVertexAttribPointer(aPos, 3, GLES20.GL_FLOAT, false, 24, vb)
        GLES20.glEnableVertexAttribArray(aPos)
        vb.position(3)
        GLES20.glVertexAttribPointer(aNormal, 3, GLES20.GL_FLOAT, false, 24, vb)
        GLES20.glEnableVertexAttribArray(aNormal)
        GLES20.glDrawElements(GLES20.GL_TRIANGLES, count, GLES20.GL_UNSIGNED_SHORT, ib)
    }
}

class ForgeRenderer(
    private val scene: Scene,
    private val camera: OrbitCamera
) : GLSurfaceView.Renderer {

    @Volatile
    var selectedId: Int = -1

    private var program = 0
    private var aPos = 0
    private var aNormal = 0
    private var uMvp = 0
    private var uModel = 0
    private var uColor = 0
    private var uLit = 0

    private var cube: GpuMesh? = null
    private var sphere: GpuMesh? = null
    private var plane: GpuMesh? = null
    private var gridBuf: FloatBuffer? = null
    private var gridLineVerts = 0

    private val proj = FloatArray(16)
    private val view = FloatArray(16)
    private val viewProj = FloatArray(16)
    private val model = FloatArray(16)
    private val mvp = FloatArray(16)
    private val identity = FloatArray(16).also { Matrix.setIdentityM(it, 0) }

    private fun compile(type: Int, src: String): Int {
        val s = GLES20.glCreateShader(type)
        GLES20.glShaderSource(s, src)
        GLES20.glCompileShader(s)
        val ok = IntArray(1)
        GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0)
        if (ok[0] == 0) {
            val log = GLES20.glGetShaderInfoLog(s)
            GLES20.glDeleteShader(s)
            throw RuntimeException("Shader compile failed: $log")
        }
        return s
    }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        val vs = compile(GLES20.GL_VERTEX_SHADER, VERTEX_SRC)
        val fs = compile(GLES20.GL_FRAGMENT_SHADER, FRAGMENT_SRC)
        program = GLES20.glCreateProgram()
        GLES20.glAttachShader(program, vs)
        GLES20.glAttachShader(program, fs)
        GLES20.glLinkProgram(program)
        val ok = IntArray(1)
        GLES20.glGetProgramiv(program, GLES20.GL_LINK_STATUS, ok, 0)
        if (ok[0] == 0) throw RuntimeException("Program link failed: " + GLES20.glGetProgramInfoLog(program))

        aPos = GLES20.glGetAttribLocation(program, "aPos")
        aNormal = GLES20.glGetAttribLocation(program, "aNormal")
        uMvp = GLES20.glGetUniformLocation(program, "uMvp")
        uModel = GLES20.glGetUniformLocation(program, "uModel")
        uColor = GLES20.glGetUniformLocation(program, "uColor")
        uLit = GLES20.glGetUniformLocation(program, "uLit")

        cube = GpuMesh(Meshes.cube())
        sphere = GpuMesh(Meshes.sphere())
        plane = GpuMesh(Meshes.plane())

        // grid lines (without axes), then the X axis, then the Z axis
        val g = ArrayList<Float>()
        val n = 10f
        fun line(x1: Float, z1: Float, x2: Float, z2: Float) {
            g.add(x1)
            g.add(0f)
            g.add(z1)
            g.add(x2)
            g.add(0f)
            g.add(z2)
        }
        for (i in -10..10) {
            if (i == 0) continue
            line(i.toFloat(), -n, i.toFloat(), n)
            line(-n, i.toFloat(), n, i.toFloat())
        }
        gridLineVerts = g.size / 3
        line(-n, 0f, n, 0f)
        line(0f, -n, 0f, n)
        gridBuf = ByteBuffer.allocateDirect(g.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply {
            put(g.toFloatArray())
            position(0)
        }

        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        GLES20.glDepthFunc(GLES20.GL_LEQUAL)
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        GLES20.glViewport(0, 0, width, height)
        val aspect = if (height == 0) 1f else width.toFloat() / height
        Matrix.perspectiveM(proj, 0, 50f, aspect, 0.1f, 200f)
    }

    private fun drawLines(first: Int, count: Int, r: Float, g: Float, b: Float) {
        val buf = gridBuf ?: return
        GLES20.glUniform4f(uColor, r, g, b, 1f)
        buf.position(0)
        GLES20.glVertexAttribPointer(aPos, 3, GLES20.GL_FLOAT, false, 12, buf)
        GLES20.glEnableVertexAttribArray(aPos)
        GLES20.glDrawArrays(GLES20.GL_LINES, first, count)
    }

    override fun onDrawFrame(gl: GL10?) {
        GLES20.glClearColor(0.055f, 0.07f, 0.125f, 1f)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        GLES20.glUseProgram(program)

        val yaw = Math.toRadians(camera.yaw.toDouble()).toFloat()
        val pitch = Math.toRadians(camera.pitch.toDouble()).toFloat()
        val d = camera.distance
        val ex = d * cos(pitch) * sin(yaw)
        val ey = d * sin(pitch) + 0.5f
        val ez = d * cos(pitch) * cos(yaw)
        Matrix.setLookAtM(view, 0, ex, ey, ez, 0f, 0.5f, 0f, 0f, 1f, 0f)
        Matrix.multiplyMM(viewProj, 0, proj, 0, view, 0)

        // grid and axes (unlit)
        GLES20.glUniformMatrix4fv(uMvp, 1, false, viewProj, 0)
        GLES20.glUniformMatrix4fv(uModel, 1, false, identity, 0)
        GLES20.glUniform1f(uLit, 0f)
        GLES20.glDisableVertexAttribArray(aNormal)
        GLES20.glVertexAttrib3f(aNormal, 0f, 1f, 0f)
        drawLines(0, gridLineVerts, 0.22f, 0.25f, 0.38f)
        drawLines(gridLineVerts, 2, 0.9f, 0.3f, 0.3f)
        drawLines(gridLineVerts + 2, 2, 0.3f, 0.5f, 0.95f)

        // objects (lit)
        GLES20.glUniform1f(uLit, 1f)
        val selected = selectedId
        for (o in scene.objects) {
            Matrix.setIdentityM(model, 0)
            Matrix.translateM(model, 0, o.position.x, o.position.y, o.position.z)
            Matrix.rotateM(model, 0, o.rotation.y, 0f, 1f, 0f)
            Matrix.rotateM(model, 0, o.rotation.x, 1f, 0f, 0f)
            Matrix.rotateM(model, 0, o.rotation.z, 0f, 0f, 1f)
            Matrix.scaleM(model, 0, o.scale.x, o.scale.y, o.scale.z)
            Matrix.multiplyMM(mvp, 0, viewProj, 0, model, 0)
            GLES20.glUniformMatrix4fv(uMvp, 1, false, mvp, 0)
            GLES20.glUniformMatrix4fv(uModel, 1, false, model, 0)

            var r = o.color.x
            var g = o.color.y
            var b = o.color.z
            if (o.id == selected) {
                r += (1f - r) * 0.45f
                g += (1f - g) * 0.45f
                b += (1f - b) * 0.45f
            }
            GLES20.glUniform4f(uColor, r, g, b, 1f)

            val mesh = when (o.shape) {
                Shape.CUBE -> cube
                Shape.SPHERE -> sphere
                Shape.PLANE -> plane
            }
            mesh?.draw(aPos, aNormal)
        }
    }
}
