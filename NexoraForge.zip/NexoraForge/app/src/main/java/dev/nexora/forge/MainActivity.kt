package dev.nexora.forge

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import dev.nexora.forge.editor.EditorViewModel
import dev.nexora.forge.ui.EditorScreen
import dev.nexora.forge.ui.NexoraTheme

class MainActivity : ComponentActivity() {
    private val vm: EditorViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            NexoraTheme {
                EditorScreen(vm)
            }
        }
    }
}
