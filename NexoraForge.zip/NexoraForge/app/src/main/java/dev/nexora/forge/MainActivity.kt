package dev.nexora.forge

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import dev.nexora.forge.editor.EditorViewModel
import dev.nexora.forge.ui.EditorScreen
import dev.nexora.forge.ui.GameScreen
import dev.nexora.forge.ui.NexoraTheme
import dev.nexora.forge.ui.StartScreen

class MainActivity : ComponentActivity() {
    private val vm: EditorViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            NexoraTheme {
                when {
                    vm.gameMode -> GameScreen(vm)
                    vm.projectName == null -> StartScreen(vm)
                    else -> EditorScreen(vm)
                }
            }
        }
    }
}
