package dev.nexora.forge.editor

import forge.core.ProjectData
import forge.core.ProjectFormat
import java.io.File

/** Projects live as single .nxf files in filesDir/projects. */
class ProjectStore(root: File) {
    private val dir = File(root, "projects").also { it.mkdirs() }

    fun list(): List<String> =
        (dir.listFiles { f -> f.isFile && f.name.endsWith(".nxf") } ?: emptyArray())
            .sortedByDescending { it.lastModified() }
            .map { it.name.removeSuffix(".nxf") }

    private fun safe(name: String): String {
        val n = name.trim().replace(Regex("[\\\\/:*?\"<>|]"), "_")
        return n.ifEmpty { "Project" }
    }

    fun uniqueName(wanted: String): String {
        val base = safe(wanted)
        val existing = list().map { it.lowercase() }.toSet()
        var n = base
        var i = 2
        while (n.lowercase() in existing) n = "$base $i".also { i++ }
        return n
    }

    fun fileFor(name: String) = File(dir, safe(name) + ".nxf")

    fun save(data: ProjectData) {
        val f = fileFor(data.name)
        val tmp = File(dir, f.name + ".tmp")
        tmp.writeText(ProjectFormat.toJson(data))
        if (!tmp.renameTo(f)) {
            f.writeText(tmp.readText())
            tmp.delete()
        }
    }

    fun load(name: String): ProjectData = ProjectFormat.fromJson(fileFor(name).readText())

    fun delete(name: String) {
        fileFor(name).delete()
    }
}
