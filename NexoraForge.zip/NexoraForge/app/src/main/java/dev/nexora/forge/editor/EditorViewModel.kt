package dev.nexora.forge.editor

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import forge.core.GameClock
import forge.core.GameModule
import forge.core.OrbitCamera
import forge.core.Scene
import forge.core.SceneObject
import forge.core.SceneState
import forge.core.Shape
import forge.core.Vec3
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import nx.Nx
import nx.NxException
import nx.NxInterpreter
import java.io.File

data class ConsoleLine(val isError: Boolean, val text: String)

class EditorViewModel(app: Application) : AndroidViewModel(app) {
    val scene = Scene()
    val clock = GameClock()
    val camera = OrbitCamera()

    /** Bumped on every scene change so Compose can recompose panels. */
    var sceneVersion by mutableIntStateOf(0)
        private set

    var selectedId by mutableStateOf<Int?>(null)
        private set

    var script by mutableStateOf("")
        private set

    var playing by mutableStateOf(false)
        private set

    val console = mutableStateListOf<ConsoleLine>()

    private val scriptFile = File(app.filesDir, "main.nx")
    private var saveJob: Job? = null
    private var interpreter: NxInterpreter? = null
    private var snapshot: SceneState? = null
    private var counter = 1

    init {
        scene.onChange = { sceneVersion++ }
        scene.add(
            "Ground", Shape.PLANE,
            position = Vec3(0f, -0.01f, 0f),
            scale = Vec3(12f, 1f, 12f)
        )
        script = try {
            if (scriptFile.exists()) scriptFile.readText() else SampleScript.TEXT
        } catch (e: Exception) {
            SampleScript.TEXT
        }
    }

    private fun log(isError: Boolean, text: String) {
        console.add(ConsoleLine(isError, text))
        while (console.size > 500) console.removeAt(0)
    }

    fun clearConsole() = console.clear()

    // ---------- scripts ----------

    fun onScriptChange(text: String) {
        script = text
        saveJob?.cancel()
        saveJob = viewModelScope.launch(Dispatchers.IO) {
            delay(400)
            try {
                scriptFile.writeText(text)
            } catch (e: Exception) {
                // best effort; the text stays in memory
            }
        }
    }

    fun resetSample() = onScriptChange(SampleScript.TEXT)

    // ---------- play mode ----------

    fun play() {
        if (playing) return
        val program = try {
            Nx.parse(script)
        } catch (e: NxException) {
            log(true, e.message)
            return
        }
        val saved = scene.capture()
        clock.reset()
        val interp = NxInterpreter(
            out = { log(false, it) },
            modules = GameModule.modules(scene, clock)
        )
        try {
            interp.run(program)
        } catch (e: NxException) {
            log(true, e.message)
            scene.restore(saved)
            fixSelection()
            return
        }
        snapshot = saved
        interpreter = interp
        playing = true
        log(false, "> Play")
    }

    fun stop() {
        if (!playing) return
        playing = false
        interpreter = null
        snapshot?.let { scene.restore(it) }
        snapshot = null
        fixSelection()
        log(false, "> Stop (scene restored)")
    }

    /** Called once per frame while playing. */
    fun tick(dt: Float) {
        val interp = interpreter ?: return
        clock.advance(dt)
        if (!interp.hasAction("update")) return
        val arity = interp.actionArity("update") ?: 0
        val args: List<Any?> = listOf<Any?>(dt.toDouble()).take(arity)
        try {
            interp.callAction("update", args)
        } catch (e: NxException) {
            log(true, e.message)
            stop()
        }
    }

    // ---------- scene editing ----------

    fun select(id: Int?) {
        selectedId = id
    }

    fun addObject(shape: Shape) {
        val n = counter++
        val y = if (shape == Shape.PLANE) 0f else 0.5f
        val scale = if (shape == Shape.PLANE) Vec3(4f, 1f, 4f) else Vec3.ONE
        val o = scene.add("${shape.label.replaceFirstChar { it.uppercase() }} $n", shape, Vec3(0f, y, 0f), scale)
        selectedId = o.id
    }

    fun deleteObject(id: Int) {
        scene.remove(id)
        if (selectedId == id) selectedId = null
    }

    fun updateObject(id: Int, change: (SceneObject) -> SceneObject) {
        scene.update(id, change)
    }

    fun selectedObject(): SceneObject? {
        val id = selectedId ?: return null
        return scene.get(id)
    }

    private fun fixSelection() {
        val id = selectedId
        if (id != null && scene.get(id) == null) selectedId = null
    }

    override fun onCleared() {
        try {
            scriptFile.writeText(script)
        } catch (e: Exception) {
            // ignore
        }
    }
}
