package dev.nexora.forge.editor

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import forge.core.GameClock
import forge.core.Anim
import forge.core.AnimClip
import forge.core.AnimationPlayer
import forge.core.GameModule
import forge.core.GizmoMode
import forge.core.NxScriptFile
import forge.core.OrbitCamera
import forge.core.ProjectData
import forge.core.ProjectFormat
import forge.core.ProjectFormatException
import forge.core.Scene
import forge.core.SceneObject
import forge.core.SceneState
import forge.core.Shape
import forge.core.Vec3
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import nx.Nx
import nx.NxException
import nx.NxInterpreter
import java.io.InputStream
import java.io.OutputStream

data class ConsoleLine(val isError: Boolean, val text: String)

class EditorViewModel(app: Application) : AndroidViewModel(app) {
    val scene = Scene()
    val clock = GameClock()
    val camera = OrbitCamera()
    private val store = ProjectStore(app.filesDir)

    /** Bumped on every scene change so Compose can recompose panels. */
    var sceneVersion by mutableIntStateOf(0)
        private set

    var selectedId by mutableStateOf<Int?>(null)
        private set

    /** Folder selected in the Outliner; new objects are created inside it. */
    var selectedFolderId by mutableStateOf<Int?>(null)
        private set

    var gizmoMode by mutableStateOf(GizmoMode.MOVE)

    /** Edit = normal scene editing. Animate = timeline and keyframes. */
    var animateMode by mutableStateOf(false)
        private set

    val clips = mutableStateListOf<AnimClip>()

    var activeClip by mutableIntStateOf(0)
        private set

    /** Timeline cursor in seconds. */
    var animTime by mutableStateOf(0f)
        private set

    var previewing by mutableStateOf(false)
        private set

    /** Scene as it was when Animate mode was entered; animated objects return to it on exit. */
    private var animBase: SceneState? = null
    private var player: AnimationPlayer? = null

    val expandedFolders = mutableStateListOf<Int>()

    var playing by mutableStateOf(false)
        private set

    val console = mutableStateListOf<ConsoleLine>()

    // ---------- project state ----------

    /** null = start screen. */
    var projectName by mutableStateOf<String?>(null)
        private set

    var projectList by mutableStateOf<List<String>>(emptyList())
        private set

    val scripts = mutableStateListOf<NxScriptFile>()

    var activeScript by mutableIntStateOf(0)
        private set

    /** Text of the open script. */
    val script: String get() = scripts.getOrNull(activeScript)?.text ?: ""

    private var saveJob: Job? = null
    private var interpreter: NxInterpreter? = null
    private var snapshot: SceneState? = null
    private var counter = 1

    init {
        scene.onChange = {
            sceneVersion++
            requestSave()
        }
        refreshProjects()
    }

    private fun log(isError: Boolean, text: String) {
        console.add(ConsoleLine(isError, text))
        while (console.size > 500) console.removeAt(0)
    }

    fun clearConsole() = console.clear()

    // ---------- projects ----------

    fun refreshProjects() {
        projectList = store.list()
    }

    private fun load(data: ProjectData) {
        saveJob?.cancel()
        projectName = null // no autosave while the scene is being swapped
        interpreter = null
        playing = false
        snapshot = null
        scene.restore(data.scene)
        animateMode = false
        previewing = false
        animBase = null
        player = null
        clips.clear()
        clips.addAll(data.clips)
        activeClip = 0
        animTime = 0f
        scripts.clear()
        scripts.addAll(data.scripts.ifEmpty { listOf(NxScriptFile("main.nx", SampleScript.TEXT)) })
        activeScript = data.activeScript.coerceIn(0, scripts.size - 1)
        projectName = data.name
        selectedId = null
        selectedFolderId = null
        expandedFolders.clear()
        counter = data.scene.nextId
        console.clear()
    }

    fun createProject(name: String) {
        val unique = store.uniqueName(name.ifBlank { "Project" })
        val fresh = Scene()
        fresh.add("Ground", Shape.PLANE, position = Vec3(0f, -0.01f, 0f), scale = Vec3(12f, 1f, 12f))
        val data = ProjectData(unique, listOf(NxScriptFile("main.nx", SampleScript.TEXT)), 0, fresh.capture(), emptyList())
        try {
            store.save(data)
        } catch (e: Exception) {
            log(true, "Cannot save project: ${e.message}")
        }
        load(data)
        refreshProjects()
    }

    fun openProject(name: String) {
        try {
            load(store.load(name))
        } catch (e: ProjectFormatException) {
            log(true, e.message ?: "Broken project")
        } catch (e: Exception) {
            log(true, "Cannot open project: ${e.message}")
        }
    }

    /** Returns an error text or null on success. */
    fun importProject(input: InputStream): String? {
        return try {
            val data = ProjectFormat.fromJson(input.bufferedReader().readText())
            val renamed = data.copy(name = store.uniqueName(data.name))
            store.save(renamed)
            refreshProjects()
            load(renamed)
            null
        } catch (e: ProjectFormatException) {
            e.message ?: "Broken project file"
        } catch (e: Exception) {
            "Cannot import: ${e.message}"
        }
    }

    /** Returns an error text or null on success. */
    fun exportProject(output: OutputStream): String? {
        return try {
            output.bufferedWriter().use { it.write(ProjectFormat.toJson(currentData())) }
            null
        } catch (e: Exception) {
            "Cannot export: ${e.message}"
        }
    }

    fun deleteProject(name: String) {
        store.delete(name)
        refreshProjects()
    }

    fun closeProject() {
        if (playing) stop()
        changeAnimateMode(false)
        saveNow()
        projectName = null
        refreshProjects()
    }

    private fun currentData(): ProjectData {
        // While playing the scene is changed by the script; the saved scene is the pre-Run snapshot.
        var state = snapshot ?: scene.capture()
        val base = animBase
        // While posing in Animate mode the saved scene keeps the rest pose of animated objects.
        if (base != null) state = Anim.withRest(state, base, Anim.animatedIds(clips.toList()))
        return ProjectData(projectName ?: "Project", scripts.toList(), activeScript, state, clips.toList())
    }

    private fun requestSave() {
        if (projectName == null || playing) return
        saveJob?.cancel()
        saveJob = viewModelScope.launch(Dispatchers.IO) {
            delay(400)
            saveNow()
        }
    }

    private fun saveNow() {
        if (projectName == null) return
        try {
            store.save(currentData())
        } catch (e: Exception) {
            // best effort; data stays in memory
        }
    }

    // ---------- scripts ----------

    fun selectScript(index: Int) {
        if (index in scripts.indices) {
            activeScript = index
            requestSave()
        }
    }

    fun onScriptChange(text: String) {
        val i = activeScript
        if (i !in scripts.indices) return
        scripts[i] = scripts[i].copy(text = text)
        requestSave()
    }

    fun addScript(name: String) {
        val unique = ProjectFormat.uniqueScriptName(name.ifBlank { "script" }, scripts.map { it.name })
        scripts.add(NxScriptFile(unique, "# $unique\n"))
        activeScript = scripts.size - 1
        requestSave()
    }

    fun renameScript(index: Int, name: String) {
        val cur = scripts.getOrNull(index) ?: return
        val others = scripts.filterIndexed { i, _ -> i != index }.map { it.name }
        scripts[index] = cur.copy(name = ProjectFormat.uniqueScriptName(name, others))
        requestSave()
    }

    /** The last script cannot be deleted. */
    fun deleteScript(index: Int) {
        if (scripts.size <= 1 || index !in scripts.indices) return
        scripts.removeAt(index)
        activeScript = activeScript.coerceIn(0, scripts.size - 1)
        requestSave()
    }

    fun resetSample() = onScriptChange(SampleScript.TEXT)

    // ---------- play mode ----------

    /** Runs the open script. Scripts are independent of each other for now. */
    fun play() {
        if (playing) return
        changeAnimateMode(false)
        val program = try {
            Nx.parse(script)
        } catch (e: NxException) {
            log(true, e.message)
            return
        }
        val saved = scene.capture()
        clock.reset()
        val clipsNow = clips.toList()
        val pl = AnimationPlayer(scene)
        player = pl
        val interp = NxInterpreter(
            out = { log(false, it) },
            modules = GameModule.modules(scene, clock),
            onAction = { name -> pl.trigger(name, clipsNow) }
        )
        try {
            interp.run(program)
        } catch (e: NxException) {
            log(true, e.message)
            player = null
            scene.restore(saved)
            fixSelection()
            return
        }
        snapshot = saved
        interpreter = interp
        playing = true
        log(false, "> Play: ${scripts[activeScript].name}")
    }

    fun stop() {
        if (!playing) return
        playing = false
        interpreter = null
        player?.stopAll()
        player = null
        snapshot?.let { scene.restore(it) }
        snapshot = null
        fixSelection()
        log(false, "> Stop (scene restored)")
    }

    /** Called once per frame while playing: script `update` first, then animations. */
    fun tick(dt: Float) {
        val interp = interpreter ?: return
        clock.advance(dt)
        if (interp.hasAction("update")) {
            val arity = interp.actionArity("update") ?: 0
            val args: List<Any?> = listOf<Any?>(dt.toDouble()).take(arity)
            try {
                interp.callAction("update", args)
            } catch (e: NxException) {
                log(true, e.message)
                stop()
                return
            }
        }
        player?.advance(dt)
    }

    // ---------- animation ----------

    fun changeAnimateMode(on: Boolean) {
        if (on == animateMode) return
        if (on) {
            if (playing) return
            animBase = scene.capture()
            animateMode = true
            if (clips.isNotEmpty()) applyAnimTime()
        } else {
            previewing = false
            val base = animBase
            if (base != null) {
                val ids = Anim.animatedIds(clips.toList())
                for (b in base.objects) {
                    if (b.id in ids) scene.update(b.id) { it.copy(position = b.position, rotation = b.rotation, scale = b.scale) }
                }
            }
            animBase = null
            animateMode = false
        }
    }

    fun currentClip(): AnimClip? = clips.getOrNull(activeClip)

    private fun replaceClip(index: Int, clip: AnimClip) {
        if (index in clips.indices) {
            clips[index] = clip
            requestSave()
        }
    }

    fun selectClip(index: Int) {
        if (index in clips.indices) {
            previewing = false
            activeClip = index
            animTime = 0f
            applyAnimTime()
        }
    }

    fun addClip(name: String) {
        val id = (clips.maxOfOrNull { it.id } ?: 0) + 1
        clips.add(AnimClip(id, name.trim().ifBlank { "Animation $id" }))
        activeClip = clips.size - 1
        animTime = 0f
        requestSave()
    }

    fun renameClip(name: String) {
        val c = currentClip() ?: return
        if (name.isNotBlank()) replaceClip(activeClip, c.copy(name = name.trim()))
    }

    fun deleteClip() {
        if (activeClip !in clips.indices) return
        previewing = false
        clips.removeAt(activeClip)
        activeClip = activeClip.coerceIn(0, maxOf(0, clips.size - 1))
        animTime = 0f
        requestSave()
    }

    /** Name of the NX action that starts the clip. Returns false if the text is not a valid action name. */
    fun setClipAction(raw: String): Boolean {
        val c = currentClip() ?: return false
        val name = Anim.normalizeAction(raw)
        if (!Anim.isValidAction(name)) return false
        replaceClip(activeClip, c.copy(action = name))
        return true
    }

    fun setClipDuration(seconds: Float) {
        val c = currentClip() ?: return
        val updated = Anim.withDuration(c, seconds)
        replaceClip(activeClip, updated)
        if (animTime > updated.duration) animTime = updated.duration
    }

    fun setClipLoop(loop: Boolean) {
        val c = currentClip() ?: return
        replaceClip(activeClip, c.copy(loop = loop))
    }

    fun actionDeclared(name: String): Boolean = Anim.declaresAction(scripts.toList(), name)

    fun seekAnim(t: Float) {
        val c = currentClip() ?: return
        animTime = t.coerceIn(0f, c.duration)
        applyAnimTime()
    }

    private fun applyAnimTime() {
        val c = currentClip() ?: return
        Anim.applyTo(scene, c, animTime)
    }

    /** Stores the selected object's current transform as a key at the timeline cursor. */
    fun addKey() {
        val c = currentClip() ?: return
        val o = selectedObject() ?: return
        replaceClip(activeClip, Anim.setKey(c, o, animTime))
    }

    fun removeKey() {
        val c = currentClip() ?: return
        val id = selectedId ?: return
        replaceClip(activeClip, Anim.removeKey(c, id, animTime))
        applyAnimTime()
    }

    fun togglePreview() {
        if (currentClip() == null) return
        if (!previewing && animTime >= (currentClip()?.duration ?: 0f)) animTime = 0f
        previewing = !previewing
    }

    /** Called every frame while previewing in Animate mode. */
    fun previewTick(dt: Float) {
        val c = currentClip()
        if (!previewing || c == null) {
            previewing = false
            return
        }
        var t = animTime + dt
        if (t >= c.duration) {
            if (c.loop && c.duration > 0f) {
                t %= c.duration
            } else {
                t = c.duration
                previewing = false
            }
        }
        animTime = t
        applyAnimTime()
    }

    // ---------- scene editing ----------

    fun select(id: Int?) {
        selectedId = id
        if (id != null) selectedFolderId = null
    }

    fun selectFolder(id: Int?) {
        selectedFolderId = id
        if (id != null) selectedId = null
    }

    fun toggleFolder(id: Int) {
        if (!expandedFolders.remove(id)) expandedFolders.add(id)
    }

    fun addObject(shape: Shape) {
        val n = counter++
        val y = if (shape == Shape.PLANE) 0f else 0.5f
        val scale = if (shape == Shape.PLANE) Vec3(4f, 1f, 4f) else Vec3.ONE
        val folder = selectedFolderId
        val o = scene.add(
            "${shape.label.replaceFirstChar { it.uppercase() }} $n", shape, Vec3(0f, y, 0f), scale,
            folderId = folder
        )
        if (folder != null && folder !in expandedFolders) expandedFolders.add(folder)
        selectedId = o.id
    }

    fun addFolder(name: String) {
        val parent = selectedFolderId
        val f = scene.addFolder(name, parent)
        if (parent != null && parent !in expandedFolders) expandedFolders.add(parent)
        selectedFolderId = f.id
        selectedId = null
    }

    fun renameFolder(id: Int, name: String) {
        scene.renameFolder(id, name)
    }

    fun deleteFolder(id: Int) {
        scene.removeFolder(id)
        if (selectedFolderId == id) selectedFolderId = null
    }

    fun moveObject(id: Int, folderId: Int?) {
        scene.moveObject(id, folderId)
        if (folderId != null && folderId !in expandedFolders) expandedFolders.add(folderId)
    }

    fun moveFolder(id: Int, parentId: Int?) {
        scene.moveFolder(id, parentId)
        if (parentId != null && parentId !in expandedFolders) expandedFolders.add(parentId)
    }

    fun deleteObject(id: Int) {
        scene.remove(id)
        if (selectedId == id) selectedId = null
    }

    fun updateObject(id: Int, change: (SceneObject) -> SceneObject) {
        scene.update(id, change)
    }

    fun selectedObject(): SceneObject? {
        val id = selectedId ?: return null
        return scene.get(id)
    }

    private fun fixSelection() {
        val id = selectedId
        if (id != null && scene.get(id) == null) selectedId = null
        val fid = selectedFolderId
        if (fid != null && scene.getFolder(fid) == null) selectedFolderId = null
    }

    override fun onCleared() {
        saveNow()
    }
}
