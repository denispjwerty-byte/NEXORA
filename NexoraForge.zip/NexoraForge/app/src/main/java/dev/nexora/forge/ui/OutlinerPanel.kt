package dev.nexora.forge.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.nexora.forge.editor.EditorViewModel
import forge.core.Folder
import forge.core.OutlinerRow
import forge.core.SceneObject
import forge.core.Shape
import forge.core.outlinerRows

@Composable
fun OutlinerPanel(vm: EditorViewModel) {
    val expanded = vm.expandedFolders.toList()
    val rows = remember(vm.sceneVersion, expanded) {
        outlinerRows(vm.scene.objects, vm.scene.folders, expanded.toSet())
    }
    var newFolder by remember { mutableStateOf(false) }
    var renameFolder by remember { mutableStateOf<Folder?>(null) }
    var renameObject by remember { mutableStateOf<SceneObject?>(null) }
    var moveFolder by remember { mutableStateOf<Folder?>(null) }
    var moveObject by remember { mutableStateOf<SceneObject?>(null) }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Shape.values().forEach { s ->
                FilledTonalButton(
                    onClick = { vm.addObject(s) },
                    contentPadding = PaddingValues(horizontal = 12.dp)
                ) { Text("+ ${s.label}", fontSize = 13.sp) }
            }
            FilledTonalButton(
                onClick = { newFolder = true },
                contentPadding = PaddingValues(horizontal = 12.dp)
            ) { Text("+ folder", fontSize = 13.sp) }
        }
        Spacer(Modifier.height(6.dp))
        if (rows.isEmpty()) Text("Empty scene", color = ForgeColors.Muted)
        LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            items(rows, key = {
                when (it) {
                    is OutlinerRow.FolderRow -> "f${it.folder.id}"
                    is OutlinerRow.ObjectRow -> "o${it.obj.id}"
                }
            }) { row ->
                when (row) {
                    is OutlinerRow.FolderRow -> {
                        val f = row.folder
                        val selected = vm.selectedFolderId == f.id
                        OutlinerLine(
                            depth = row.depth,
                            selected = selected,
                            title = (if (row.expanded) "v  " else ">  ") + f.name,
                            subtitle = "${row.childCount}",
                            onClick = { vm.selectFolder(f.id); vm.toggleFolder(f.id) },
                            onRename = { renameFolder = f },
                            onMove = { moveFolder = f },
                            onDelete = { vm.deleteFolder(f.id) }
                        )
                    }
                    is OutlinerRow.ObjectRow -> {
                        val o = row.obj
                        OutlinerLine(
                            depth = row.depth,
                            selected = vm.selectedId == o.id,
                            title = o.name,
                            subtitle = o.shape.label,
                            onClick = { vm.select(o.id) },
                            onRename = { renameObject = o },
                            onMove = { moveObject = o },
                            onDelete = { vm.deleteObject(o.id) }
                        )
                    }
                }
            }
        }
    }

    if (newFolder) {
        TextInputDialog("New folder", "Folder", "Create", { vm.addFolder(it) }, { newFolder = false })
    }
    renameFolder?.let { f ->
        TextInputDialog("Rename folder", f.name, "Rename", { vm.renameFolder(f.id, it) }, { renameFolder = null })
    }
    renameObject?.let { o ->
        TextInputDialog(
            "Rename object", o.name, "Rename",
            { n -> if (n.isNotBlank()) vm.updateObject(o.id) { it.copy(name = n.trim()) } },
            { renameObject = null }
        )
    }
    moveObject?.let { o ->
        PickFolderDialog("Move \"${o.name}\" to", vm.scene.folders, emptySet(), { vm.moveObject(o.id, it) }, { moveObject = null })
    }
    moveFolder?.let { f ->
        val blocked = vm.scene.folders.filter { vm.scene.isInside(it.id, f.id) }.map { it.id }.toSet()
        PickFolderDialog("Move \"${f.name}\" to", vm.scene.folders, blocked, { vm.moveFolder(f.id, it) }, { moveFolder = null })
    }
}

@Composable
private fun OutlinerLine(
    depth: Int,
    selected: Boolean,
    title: String,
    subtitle: String,
    onClick: () -> Unit,
    onRename: () -> Unit,
    onMove: () -> Unit,
    onDelete: () -> Unit
) {
    var menu by remember { mutableStateOf(false) }
    Row(
        Modifier
            .fillMaxWidth()
            .background(if (selected) ForgeColors.Accent.copy(alpha = 0.35f) else ForgeColors.Row)
            .clickable(onClick = onClick)
            .padding(start = (12 + 16 * depth).dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, color = ForgeColors.Text, modifier = Modifier.weight(1f), maxLines = 1)
        Text(subtitle, color = ForgeColors.Muted, fontSize = 12.sp)
        Box {
            TextButton(onClick = { menu = true }, contentPadding = PaddingValues(horizontal = 10.dp)) {
                Text("...", color = ForgeColors.Text)
            }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(text = { Text("Rename") }, onClick = { menu = false; onRename() })
                DropdownMenuItem(text = { Text("Move to folder") }, onClick = { menu = false; onMove() })
                DropdownMenuItem(
                    text = { Text("Delete", color = ForgeColors.Error) },
                    onClick = { menu = false; onDelete() }
                )
            }
        }
    }
}
