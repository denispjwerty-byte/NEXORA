package dev.nexora.forge.ui

import android.content.res.Configuration
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.nexora.forge.editor.EditorViewModel
import dev.nexora.forge.viewport.GlViewport
import forge.core.Shape
import forge.core.Vec3
import java.util.Locale

@Composable
fun EditorScreen(vm: EditorViewModel) {
    var tab by rememberSaveable { mutableStateOf(0) }
    val landscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE

    // Frame loop for Play mode: calls the NX `update` action once per frame.
    LaunchedEffect(vm.playing) {
        if (vm.playing) {
            var last = 0L
            while (true) {
                withFrameNanos { now ->
                    if (last != 0L) vm.tick(((now - last) / 1_000_000_000f).coerceAtMost(0.1f))
                    last = now
                }
            }
        }
    }

    Surface(color = MaterialTheme.colorScheme.background, modifier = Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            TopBar(vm)
            if (landscape) {
                Row(Modifier.fillMaxSize()) {
                    Viewport(vm, Modifier.weight(1f).fillMaxHeight())
                    PanelArea(vm, tab, { tab = it }, Modifier.weight(1f).fillMaxHeight())
                }
            } else {
                Viewport(vm, Modifier.fillMaxWidth().weight(0.45f))
                PanelArea(vm, tab, { tab = it }, Modifier.fillMaxWidth().weight(0.55f))
            }
        }
    }
}

@Composable
private fun TopBar(vm: EditorViewModel) {
    Row(
        Modifier
            .fillMaxWidth()
            .background(ForgeColors.TopBar)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("Nexora Forge", color = ForgeColors.Text, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Text("  NX 0.1", color = ForgeColors.Muted, fontSize = 12.sp)
        Spacer(Modifier.weight(1f))
        if (vm.playing) {
            Button(
                onClick = { vm.stop() },
                colors = ButtonDefaults.buttonColors(containerColor = ForgeColors.Stop)
            ) { Text("Stop") }
        } else {
            Button(onClick = { vm.play() }) { Text("Run") }
        }
    }
}

@Composable
private fun Viewport(vm: EditorViewModel, modifier: Modifier) {
    Box(modifier) {
        GlViewport(vm.scene, vm.camera, vm.selectedId, Modifier.fillMaxSize())
        Text(
            "drag: orbit   pinch: zoom",
            color = ForgeColors.Muted,
            fontSize = 11.sp,
            modifier = Modifier.align(Alignment.BottomStart).padding(8.dp)
        )
        if (vm.playing) {
            Text(
                "PLAYING",
                color = ForgeColors.Cyan,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                modifier = Modifier.align(Alignment.TopEnd).padding(8.dp)
            )
        }
    }
}

@Composable
private fun PanelArea(vm: EditorViewModel, tab: Int, onTab: (Int) -> Unit, modifier: Modifier) {
    val titles = listOf("Hierarchy", "Inspector", "Script", "Console")
    Column(modifier.background(ForgeColors.Panel)) {
        TabRow(
            selectedTabIndex = tab,
            containerColor = ForgeColors.Panel,
            contentColor = ForgeColors.Accent
        ) {
            titles.forEachIndexed { i, title ->
                Tab(
                    selected = tab == i,
                    onClick = { onTab(i) },
                    text = { Text(title, fontSize = 13.sp, maxLines = 1) }
                )
            }
        }
        Box(Modifier.fillMaxSize().padding(8.dp)) {
            when (tab) {
                0 -> HierarchyPanel(vm)
                1 -> InspectorPanel(vm)
                2 -> ScriptPanel(vm)
                else -> ConsolePanel(vm)
            }
        }
    }
}

@Composable
private fun HierarchyPanel(vm: EditorViewModel) {
    val objects = remember(vm.sceneVersion) { vm.scene.objects }
    Column(Modifier.fillMaxSize()) {
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Shape.values().forEach { s ->
                FilledTonalButton(
                    onClick = { vm.addObject(s) },
                    contentPadding = PaddingValues(horizontal = 12.dp)
                ) { Text("+ ${s.label}", fontSize = 13.sp) }
            }
        }
        Spacer(Modifier.height(6.dp))
        LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            items(objects, key = { it.id }) { o ->
                val selected = vm.selectedId == o.id
                Row(
                    Modifier
                        .fillMaxWidth()
                        .background(if (selected) ForgeColors.Accent.copy(alpha = 0.35f) else ForgeColors.Row)
                        .clickable { vm.select(o.id) }
                        .padding(start = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(o.name, color = ForgeColors.Text, modifier = Modifier.weight(1f))
                    Text(o.shape.label, color = ForgeColors.Muted, fontSize = 12.sp)
                    TextButton(onClick = { vm.deleteObject(o.id) }) { Text("Delete", color = ForgeColors.Error, fontSize = 12.sp) }
                }
            }
        }
    }
}

@Composable
private fun InspectorPanel(vm: EditorViewModel) {
    val o = remember(vm.sceneVersion, vm.selectedId) { vm.selectedObject() }
    if (o == null) {
        Text("Select an object in Hierarchy", color = ForgeColors.Muted)
        return
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        OutlinedTextField(
            value = o.name,
            onValueChange = { n -> vm.updateObject(o.id) { it.copy(name = n) } },
            label = { Text("Name") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        VecRow("Position", o.position) { v -> vm.updateObject(o.id) { it.copy(position = v) } }
        VecRow("Rotation (degrees)", o.rotation) { v -> vm.updateObject(o.id) { it.copy(rotation = v) } }
        VecRow("Scale", o.scale) { v -> vm.updateObject(o.id) { it.copy(scale = v) } }
        VecRow("Color (R G B, 0..1)", o.color) { v ->
            vm.updateObject(o.id) {
                it.copy(color = Vec3(v.x.coerceIn(0f, 1f), v.y.coerceIn(0f, 1f), v.z.coerceIn(0f, 1f)))
            }
        }
    }
}

@Composable
private fun VecRow(label: String, v: Vec3, onChange: (Vec3) -> Unit) {
    Column(Modifier.padding(top = 8.dp)) {
        Text(label, color = ForgeColors.Muted, fontSize = 12.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            NumField("X", v.x, Modifier.weight(1f)) { onChange(v.copy(x = it)) }
            NumField("Y", v.y, Modifier.weight(1f)) { onChange(v.copy(y = it)) }
            NumField("Z", v.z, Modifier.weight(1f)) { onChange(v.copy(z = it)) }
        }
    }
}

private fun fmt(v: Float): String {
    val s = String.format(Locale.US, "%.3f", v).trimEnd('0').trimEnd('.')
    return if (s.isEmpty() || s == "-") "0" else s
}

@Composable
private fun NumField(label: String, value: Float, modifier: Modifier, onValue: (Float) -> Unit) {
    var text by remember { mutableStateOf(fmt(value)) }
    LaunchedEffect(value) {
        if (text.replace(',', '.').toFloatOrNull() != value) text = fmt(value)
    }
    OutlinedTextField(
        value = text,
        onValueChange = { t ->
            text = t
            t.replace(',', '.').toFloatOrNull()?.let(onValue)
        },
        label = { Text(label) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        modifier = modifier
    )
}

@Composable
private fun ScriptPanel(vm: EditorViewModel) {
    Column(Modifier.fillMaxSize()) {
        Row {
            TextButton(onClick = { vm.resetSample() }) { Text("Reset sample") }
        }
        OutlinedTextField(
            value = vm.script,
            onValueChange = { vm.onScriptChange(it) },
            modifier = Modifier.fillMaxWidth().weight(1f),
            textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 13.sp),
            keyboardOptions = KeyboardOptions(
                capitalization = KeyboardCapitalization.None,
                autoCorrect = false,
                keyboardType = KeyboardType.Text
            )
        )
    }
}

@Composable
private fun ConsolePanel(vm: EditorViewModel) {
    val state = rememberLazyListState()
    LaunchedEffect(vm.console.size) {
        if (vm.console.isNotEmpty()) state.scrollToItem(vm.console.size - 1)
    }
    Column(Modifier.fillMaxSize()) {
        Row {
            TextButton(onClick = { vm.clearConsole() }) { Text("Clear") }
        }
        LazyColumn(state = state, modifier = Modifier.fillMaxSize()) {
            items(vm.console.size) { i ->
                val line = vm.console[i]
                Text(
                    line.text,
                    color = if (line.isError) ForgeColors.Error else Color(0xFFCBD3F0),
                    fontFamily = FontFamily.Monospace,
                    fontSize = 12.sp
                )
            }
        }
    }
}
