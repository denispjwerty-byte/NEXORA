package dev.nexora.forge.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.nexora.forge.editor.EditorViewModel

@Composable
fun ScriptPanel(vm: EditorViewModel) {
    var newScript by remember { mutableStateOf(false) }
    var rename by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    val active = vm.scripts.getOrNull(vm.activeScript)

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            vm.scripts.forEachIndexed { i, s ->
                Text(
                    s.name,
                    color = ForgeColors.Text,
                    fontSize = 13.sp,
                    maxLines = 1,
                    modifier = Modifier
                        .background(if (i == vm.activeScript) ForgeColors.Accent.copy(alpha = 0.45f) else ForgeColors.Row)
                        .clickable { vm.selectScript(i) }
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                )
            }
            TextButton(onClick = { newScript = true }) { Text("+ new") }
        }
        Row(Modifier.horizontalScroll(rememberScrollState())) {
            TextButton(onClick = { rename = true }) { Text("Rename") }
            TextButton(onClick = { confirmDelete = true }, enabled = vm.scripts.size > 1) {
                Text("Delete", color = if (vm.scripts.size > 1) ForgeColors.Error else ForgeColors.Muted)
            }
            TextButton(onClick = { vm.resetSample() }) { Text("Reset sample") }
        }
        OutlinedTextField(
            value = vm.script,
            onValueChange = { vm.onScriptChange(it) },
            modifier = Modifier.fillMaxWidth().weight(1f),
            textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 13.sp),
            keyboardOptions = KeyboardOptions(
                capitalization = KeyboardCapitalization.None,
                autoCorrect = false,
                keyboardType = KeyboardType.Text
            )
        )
    }

    if (newScript) {
        TextInputDialog("New script", "script", "Create", { vm.addScript(it) }, { newScript = false })
    }
    if (rename && active != null) {
        TextInputDialog("Rename script", active.name.removeSuffix(".nx"), "Rename", { vm.renameScript(vm.activeScript, it) }, { rename = false })
    }
    if (confirmDelete && active != null) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Delete ${active.name}?") },
            text = { Text("The script text will be lost.") },
            confirmButton = {
                TextButton(onClick = { vm.deleteScript(vm.activeScript); confirmDelete = false }) {
                    Text("Delete", color = ForgeColors.Error)
                }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel") } }
        )
    }
}
