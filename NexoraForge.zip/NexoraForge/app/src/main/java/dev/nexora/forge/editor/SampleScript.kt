package dev.nexora.forge.editor

object SampleScript {
    val TEXT: String = """
# Nexora Forge - sample script (NX 0.1)
# Run starts the script; Stop restores the scene.
@start
load game
load math

data cube = run spawn "Spinner", "cube", 0, 1.0, 0
data ball = run spawn "Orbiter", "sphere", 2.0, 1.0, 0
run setColor cube, 0.3, 0.6, 1.0
run setColor ball, 1.0, 0.45, 0.2

data angle = 0.0

# called by the engine every frame
action update dt
    change angle = angle + dt * 90.0
    run setRot cube, 0.0, angle, 0.0
    data a = run toRadians angle
    run setPos ball, 2.5 * (run cos a), 1.0, 2.5 * (run sin a)

say "Script started"
@stop
""".trimStart()
}
