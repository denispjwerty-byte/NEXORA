package dev.nexora.forge.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.nexora.forge.editor.EditorViewModel

@Composable
fun StartScreen(vm: EditorViewModel) {
    val context = LocalContext.current
    var showCreate by remember { mutableStateOf(false) }
    var deleteTarget by remember { mutableStateOf<String?>(null) }
    var message by remember { mutableStateOf<String?>(null) }

    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val err = try {
                context.contentResolver.openInputStream(uri)?.use { vm.importProject(it) } ?: "Cannot read the file"
            } catch (e: Exception) {
                "Cannot read the file: ${e.message}"
            }
            message = err
        }
    }

    Surface(color = MaterialTheme.colorScheme.background, modifier = Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().padding(20.dp)) {
            Text("Nexora Forge", color = ForgeColors.Text, fontWeight = FontWeight.Bold, fontSize = 26.sp)
            Text("NX 0.1", color = ForgeColors.Muted, fontSize = 12.sp)
            Spacer(Modifier.height(24.dp))

            FilledTonalButton(onClick = { importLauncher.launch(arrayOf("*/*")) }, modifier = Modifier.fillMaxWidth()) {
                Text("Import project (.nxf)")
            }
            Spacer(Modifier.height(10.dp))
            Button(onClick = { showCreate = true }, modifier = Modifier.fillMaxWidth()) {
                Text("Create project")
            }
            message?.let {
                Spacer(Modifier.height(8.dp))
                Text(it, color = ForgeColors.Error, fontSize = 13.sp)
            }

            Spacer(Modifier.height(24.dp))
            Text("Projects", color = ForgeColors.Muted, fontSize = 13.sp)
            Spacer(Modifier.height(6.dp))
            if (vm.projectList.isEmpty()) {
                Text("No projects yet", color = ForgeColors.Muted)
            }
            LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                items(vm.projectList, key = { it }) { name ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .background(ForgeColors.Row)
                            .clickable { vm.openProject(name) }
                            .padding(start = 14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(name, color = ForgeColors.Text, modifier = Modifier.weight(1f))
                        TextButton(onClick = { deleteTarget = name }) {
                            Text("Delete", color = ForgeColors.Error, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }

    if (showCreate) {
        TextInputDialog(
            title = "New project",
            initial = "My Project",
            confirmLabel = "Create",
            onConfirm = { vm.createProject(it) },
            onDismiss = { showCreate = false }
        )
    }
    deleteTarget?.let { name ->
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { deleteTarget = null },
            title = { Text("Delete \"$name\"?") },
            text = { Text("The project file will be removed from this device.") },
            confirmButton = {
                TextButton(onClick = { vm.deleteProject(name); deleteTarget = null }) {
                    Text("Delete", color = ForgeColors.Error)
                }
            },
            dismissButton = { TextButton(onClick = { deleteTarget = null }) { Text("Cancel") } }
        )
    }
}
