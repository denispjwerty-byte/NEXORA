package dev.nexora.forge.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import forge.core.Folder

@Composable
fun TextInputDialog(
    title: String,
    initial: String,
    confirmLabel: String,
    onConfirm: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        },
        confirmButton = {
            TextButton(onClick = { onConfirm(text); onDismiss() }) { Text(confirmLabel) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

/** Lists the root and all folders (nested ones indented). [excluded] folders cannot be chosen. */
@Composable
fun PickFolderDialog(
    title: String,
    folders: List<Folder>,
    excluded: Set<Int>,
    onPick: (Int?) -> Unit,
    onDismiss: () -> Unit
) {
    fun depthOf(f: Folder): Int {
        var d = 0
        var cur = f.parentId
        while (cur != null && d < 50) {
            d++
            cur = folders.firstOrNull { it.id == cur }?.parentId
        }
        return d
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column(Modifier.heightIn(max = 320.dp).verticalScroll(rememberScrollState())) {
                Row(Modifier.fillMaxWidth().clickable { onPick(null); onDismiss() }.padding(vertical = 10.dp)) {
                    Text("(root)", color = ForgeColors.Muted)
                }
                folders.filter { it.id !in excluded }.forEach { f ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable { onPick(f.id); onDismiss() }
                            .padding(start = (16 * depthOf(f)).dp, top = 10.dp, bottom = 10.dp)
                    ) { Text("[ ] ${f.name}") }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
