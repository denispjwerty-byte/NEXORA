package dev.nexora.forge.viewport

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/** Interleaved vertices: x y z nx ny nz. */
internal class MeshData(val vertices: FloatArray, val indices: ShortArray)

internal object Meshes {
    private fun cross(a: FloatArray, b: FloatArray): FloatArray = floatArrayOf(
        a[1] * b[2] - a[2] * b[1],
        a[2] * b[0] - a[0] * b[2],
        a[0] * b[1] - a[1] * b[0]
    )

    /** Unit cube, side 1, centered on the origin. */
    fun cube(): MeshData {
        val v = ArrayList<Float>()
        val idx = ArrayList<Short>()
        val normals = arrayOf(
            floatArrayOf(0f, 0f, 1f), floatArrayOf(0f, 0f, -1f),
            floatArrayOf(1f, 0f, 0f), floatArrayOf(-1f, 0f, 0f),
            floatArrayOf(0f, 1f, 0f), floatArrayOf(0f, -1f, 0f)
        )
        val corners = arrayOf(
            floatArrayOf(-1f, -1f), floatArrayOf(1f, -1f),
            floatArrayOf(1f, 1f), floatArrayOf(-1f, 1f)
        )
        for (n in normals) {
            val up = if (abs(n[1]) > 0.5f) floatArrayOf(0f, 0f, 1f) else floatArrayOf(0f, 1f, 0f)
            val right = cross(up, n)
            val up2 = cross(n, right)
            val base = v.size / 6
            for (c in corners) {
                for (k in 0..2) v.add(0.5f * n[k] + 0.5f * c[0] * right[k] + 0.5f * c[1] * up2[k])
                v.add(n[0])
                v.add(n[1])
                v.add(n[2])
            }
            for (o in intArrayOf(0, 1, 2, 0, 2, 3)) idx.add((base + o).toShort())
        }
        return MeshData(v.toFloatArray(), idx.toShortArray())
    }

    /** Unit quad in the XZ plane facing +Y. */
    fun plane(): MeshData = MeshData(
        floatArrayOf(
            -0.5f, 0f, -0.5f, 0f, 1f, 0f,
            0.5f, 0f, -0.5f, 0f, 1f, 0f,
            0.5f, 0f, 0.5f, 0f, 1f, 0f,
            -0.5f, 0f, 0.5f, 0f, 1f, 0f
        ),
        shortArrayOf(0, 2, 1, 0, 3, 2)
    )

    /** UV sphere, diameter 1. */
    fun sphere(stacks: Int = 16, slices: Int = 24): MeshData {
        val v = ArrayList<Float>()
        val idx = ArrayList<Short>()
        for (i in 0..stacks) {
            val phi = PI * i / stacks
            for (j in 0..slices) {
                val theta = 2.0 * PI * j / slices
                val x = (sin(phi) * cos(theta)).toFloat()
                val y = cos(phi).toFloat()
                val z = (sin(phi) * sin(theta)).toFloat()
                v.add(0.5f * x)
                v.add(0.5f * y)
                v.add(0.5f * z)
                v.add(x)
                v.add(y)
                v.add(z)
            }
        }
        for (i in 0 until stacks) {
            for (j in 0 until slices) {
                val a = i * (slices + 1) + j
                val b = a + slices + 1
                for (o in intArrayOf(a, b, a + 1, a + 1, b, b + 1)) idx.add(o.toShort())
            }
        }
        return MeshData(v.toFloatArray(), idx.toShortArray())
    }
}
