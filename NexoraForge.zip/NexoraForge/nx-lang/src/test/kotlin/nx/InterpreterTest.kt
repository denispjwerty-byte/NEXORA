package nx

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class InterpreterTest {
    private fun run(src: String): List<String> {
        val lines = ArrayList<String>()
        NxInterpreter(out = { lines.add(it) }).run(Nx.parse(src.trimIndent()))
        return lines
    }

    private fun errCode(src: String): String {
        try {
            run(src)
        } catch (e: NxException) {
            return e.code
        }
        return "none"
    }

    @Test
    fun hello() {
        assertEquals(listOf("Hello, Nexora!"), run("say \"Hello, Nexora!\""))
    }

    @Test
    fun arithmeticPrecedence() {
        val src = """
            data a = 2
            data b = 3
            say a + b * 4
            say (a + b) * 4
            say 7 / 2
            say 7 % 4
            say 1 + 2.5
        """
        assertEquals(listOf("14", "20", "3", "3", "3.5"), run(src))
    }

    @Test
    fun startStop() {
        val src = """
            @start
            say "in"
            @stop
        """
        assertEquals(listOf("in"), run(src))
        assertEquals("NX2005", errCode("@start\nsay \"x\""))
    }

    @Test
    fun checkOtherwise() {
        val src = """
            data age = 15
            check age >= 18
                say "Access granted"
            otherwise
                say "Access denied"
        """
        assertEquals(listOf("Access denied"), run(src))
    }

    @Test
    fun otherwiseCheckChain() {
        val src = """
            data n = 5
            check n < 0
                say "neg"
            otherwise check n == 0
                say "zero"
            otherwise
                say "pos"
        """
        assertEquals(listOf("pos"), run(src))
    }

    @Test
    fun repeatCounts() {
        val src = """
            fixed limit = 3
            data total = 0
            repeat limit
                change total = total + 1
            say total
        """
        assertEquals(listOf("3"), run(src))
    }

    @Test
    fun repeatWhile() {
        val src = """
            data i = 0
            repeat while i < 3
                change i = i + 1
            say i
        """
        assertEquals(listOf("3"), run(src))
    }

    @Test
    fun actionsParamsYieldAndHoisting() {
        val src = """
            say run add 2, 3
            action add a, b
                yield a + b
        """
        assertEquals(listOf("5"), run(src))
    }

    @Test
    fun recursion() {
        val src = """
            action fact n
                check n <= 1
                    yield 1
                yield n * (run fact n - 1)
            say run fact 5
        """
        assertEquals(listOf("120"), run(src))
    }

    @Test
    fun listsAndText() {
        val src = """
            data xs = [1, 2, 3]
            run push xs, 4
            change xs[0] = 10
            say run length xs
            say xs
            say "ab" + "cd"
        """
        assertEquals(listOf("4", "[10, 2, 3, 4]", "abcd"), run(src))
    }

    @Test
    fun attemptRecoverCatchesRuntimeErrors() {
        val src = """
            attempt
                say 1 / 0
            recover
                say "error"
                say run lastError
        """
        val out = run(src)
        assertEquals("error", out[0])
        assertTrue(out[1].startsWith("NX9001"))
    }

    @Test
    fun recoverDoesNotHideSemanticErrors() {
        val src = """
            attempt
                say missing
            recover
                say "r"
        """
        assertEquals("NX3001", errCode(src))
    }

    @Test
    fun loadMath() {
        val src = """
            load math
            say run sqrt 9.0
            say run max 2, 7
        """
        assertEquals(listOf("3.0", "7"), run(src))
        assertEquals("NX3006", errCode("say run sqrt 4.0"))
        assertEquals("NX3005", errCode("load nothing"))
    }

    @Test
    fun errorCodes() {
        assertEquals("NX3002", errCode("data x = 1\ndata x = 2"))
        assertEquals("NX3001", errCode("change y = 5"))
        assertEquals("NX3004", errCode("fixed k = 1\nchange k = 2"))
        assertEquals("NX4003", errCode("data x = 1\ncheck x\n    say \"hi\""))
        assertEquals("NX4001", errCode("say \"a\" + 1"))
        assertEquals("NX2001", errCode("check true\n\tsay \"x\""))
        assertEquals("NX1002", errCode("say \"abc"))
        assertEquals("NX9002", errCode("repeat -1\n    say \"x\""))
        assertEquals("NX2006", errCode("build Player"))
        assertEquals("NX3007", errCode("yield 1"))
    }

    @Test
    fun shadowingIsAnError() {
        val src = """
            data x = 1
            check true
                data x = 2
        """
        assertEquals("NX3003", errCode(src))
    }

    @Test
    fun infiniteLoopIsStopped() {
        val src = """
            repeat while true
                data x = 1
        """
        assertEquals("NX9010", errCode(src))
    }
}
