package nx

object Nx {
    const val VERSION = "0.1.0"

    fun parse(source: String): Program = Parser(Lexer.tokenize(source)).parseProgram()
}
