package nx

class Parser(private val toks: List<Token>) {
    private var p = 0

    private fun peek(): Token = toks[minOf(p, toks.size - 1)]
    private fun next(): Token = toks[minOf(p++, toks.size - 1)]
    private fun isKw(s: String): Boolean = peek().type == Tk.KW && peek().text == s
    private fun isOp(s: String): Boolean = peek().type == Tk.OP && peek().text == s

    private fun describe(t: Token): String = when (t.type) {
        Tk.NEWLINE -> "end of line"
        Tk.INDENT -> "an indent"
        Tk.DEDENT -> "a dedent"
        Tk.EOF -> "end of file"
        else -> "'${t.text}'"
    }

    private fun fail(msg: String, t: Token = peek()): Nothing =
        throw NxException("NX2003", msg, t.line, t.col)

    private fun expectOp(s: String) {
        if (!isOp(s)) fail("expected '$s' but found ${describe(peek())}")
        p++
    }

    private fun ident(): Token {
        val t = peek()
        if (t.type != Tk.IDENT) fail("expected a name but found ${describe(t)}")
        p++
        return t
    }

    private fun endLine() {
        when (peek().type) {
            Tk.NEWLINE -> p++
            Tk.EOF -> {}
            else -> fail("expected end of line but found ${describe(peek())}")
        }
    }

    private fun skipNewlines() {
        while (peek().type == Tk.NEWLINE) p++
    }

    fun parseProgram(): Program {
        skipNewlines()
        var started = false
        if (isKw("@start")) {
            next()
            endLine()
            started = true
        }
        val body = ArrayList<Stmt>()
        skipNewlines()
        while (peek().type != Tk.EOF && !isKw("@stop")) {
            body.add(statement(true))
            skipNewlines()
        }
        if (isKw("@stop")) {
            val t = next()
            if (!started) throw NxException("NX2005", "'@stop' without a matching '@start'", t.line, t.col)
            endLine()
            skipNewlines()
            if (peek().type != Tk.EOF) fail("code after '@stop' is not allowed")
        } else if (started) {
            throw NxException("NX2005", "missing '@stop' at the end of the program", peek().line, peek().col)
        }
        return Program(body)
    }

    private fun block(): List<Stmt> {
        when (peek().type) {
            Tk.NEWLINE -> p++
            else -> fail("expected end of line before an indented block but found ${describe(peek())}")
        }
        if (peek().type != Tk.INDENT) fail("expected an indented block")
        p++
        val out = ArrayList<Stmt>()
        while (peek().type != Tk.DEDENT && peek().type != Tk.EOF) {
            out.add(statement(false))
        }
        if (peek().type == Tk.DEDENT) p++
        return out
    }

    private fun statement(top: Boolean): Stmt {
        val t = peek()
        if (t.type == Tk.INDENT) throw NxException("NX2004", "unexpected indent", t.line, t.col)
        if (t.type == Tk.IDENT) fail("unknown statement '${t.text}'", t)
        if (t.type != Tk.KW) fail("unexpected ${describe(t)}", t)

        return when (t.text) {
            "say" -> {
                next()
                val e = expr()
                endLine()
                Say(e, t.line, t.col)
            }
            "data", "fixed" -> {
                next()
                val name = ident()
                expectOp("=")
                val e = expr()
                endLine()
                DataDecl(name.text, e, t.text == "fixed", t.line, t.col)
            }
            "change" -> {
                next()
                val target = postfix()
                if (target !is VarRef && target !is Index) fail("'change' needs a variable or a list element", t)
                expectOp("=")
                val e = expr()
                endLine()
                Change(target, e, t.line, t.col)
            }
            "ask" -> {
                next()
                val name = ident()
                endLine()
                Ask(name.text, t.line, t.col)
            }
            "check" -> checkStmt()
            "repeat" -> {
                next()
                if (isKw("while")) {
                    next()
                    val cond = expr()
                    RepeatWhile(cond, block(), t.line, t.col)
                } else {
                    val count = expr()
                    Repeat(count, block(), t.line, t.col)
                }
            }
            "action" -> {
                if (!top) fail("actions can only be declared at the top level", t)
                next()
                val name = ident()
                val params = ArrayList<String>()
                if (peek().type == Tk.IDENT) {
                    params.add(next().text)
                    while (isOp(",")) {
                        next()
                        params.add(ident().text)
                    }
                }
                val dup = params.groupBy { it }.filter { it.value.size > 1 }.keys.firstOrNull()
                if (dup != null) throw NxException("NX3002", "duplicate parameter '$dup'", t.line, t.col)
                ActionDecl(name.text, params, block(), t.line, t.col)
            }
            "run" -> {
                val call = runCall()
                endLine()
                RunStmt(call, t.line, t.col)
            }
            "yield" -> {
                next()
                val v = if (peek().type == Tk.NEWLINE || peek().type == Tk.EOF) null else expr()
                endLine()
                Yield(v, t.line, t.col)
            }
            "load" -> {
                next()
                val name = ident()
                endLine()
                Load(name.text, t.line, t.col)
            }
            "attempt" -> {
                next()
                val body = block()
                if (!isKw("recover")) fail("'attempt' needs a matching 'recover'")
                next()
                Attempt(body, block(), t.line, t.col)
            }
            "build" -> throw NxException("NX2006", "'build' is reserved but not specified yet in NX 0.1", t.line, t.col)
            else -> fail("unexpected '${t.text}'", t)
        }
    }

    private fun checkStmt(): Stmt {
        val t = next() // 'check'
        val cond = expr()
        val then = block()
        var other: List<Stmt>? = null
        if (isKw("otherwise")) {
            next()
            other = if (isKw("check")) listOf(checkStmt()) else block()
        }
        return Check(cond, then, other, t.line, t.col)
    }

    // ---- expressions: or < and < not < ==,!= < relational < +,- < *,/,% < unary - ----

    fun expr(): Expr = orExpr()

    private fun orExpr(): Expr {
        var l = andExpr()
        while (isKw("or")) {
            val t = next()
            l = Binary("or", l, andExpr(), t.line, t.col)
        }
        return l
    }

    private fun andExpr(): Expr {
        var l = notExpr()
        while (isKw("and")) {
            val t = next()
            l = Binary("and", l, notExpr(), t.line, t.col)
        }
        return l
    }

    private fun notExpr(): Expr {
        if (isKw("not")) {
            val t = next()
            return Unary("not", notExpr(), t.line, t.col)
        }
        return eqExpr()
    }

    private fun eqExpr(): Expr {
        var l = relExpr()
        while (isOp("==") || isOp("!=")) {
            val t = next()
            l = Binary(t.text, l, relExpr(), t.line, t.col)
        }
        return l
    }

    private fun relExpr(): Expr {
        var l = addExpr()
        while (isOp("<") || isOp("<=") || isOp(">") || isOp(">=")) {
            val t = next()
            l = Binary(t.text, l, addExpr(), t.line, t.col)
        }
        return l
    }

    private fun addExpr(): Expr {
        var l = mulExpr()
        while (isOp("+") || isOp("-")) {
            val t = next()
            l = Binary(t.text, l, mulExpr(), t.line, t.col)
        }
        return l
    }

    private fun mulExpr(): Expr {
        var l = unary()
        while (isOp("*") || isOp("/") || isOp("%")) {
            val t = next()
            l = Binary(t.text, l, unary(), t.line, t.col)
        }
        return l
    }

    private fun unary(): Expr {
        if (isOp("-")) {
            val t = next()
            return Unary("-", unary(), t.line, t.col)
        }
        return postfix()
    }

    private fun postfix(): Expr {
        var e = primary()
        while (isOp("[")) {
            val t = next()
            val idx = expr()
            expectOp("]")
            e = Index(e, idx, t.line, t.col)
        }
        return e
    }

    private fun startsExpr(t: Token): Boolean = when (t.type) {
        Tk.INT, Tk.FLOAT, Tk.TEXT, Tk.IDENT -> true
        Tk.KW -> t.text == "true" || t.text == "false" || t.text == "not" || t.text == "run"
        Tk.OP -> t.text == "(" || t.text == "[" || t.text == "-"
        else -> false
    }

    /** `run name a, b` - arguments extend to the right as far as possible. Use parentheses to nest. */
    private fun runCall(): RunCall {
        val t = next() // 'run'
        val name = ident()
        val args = ArrayList<Expr>()
        if (startsExpr(peek())) {
            args.add(expr())
            while (isOp(",")) {
                next()
                args.add(expr())
            }
        }
        return RunCall(name.text, args, t.line, t.col)
    }

    private fun primary(): Expr {
        val t = peek()
        return when (t.type) {
            Tk.INT -> {
                next()
                IntLit(t.text.toLong(), t.line, t.col)
            }
            Tk.FLOAT -> {
                next()
                FloatLit(t.text.toDouble(), t.line, t.col)
            }
            Tk.TEXT -> {
                next()
                TextLit(t.text, t.line, t.col)
            }
            Tk.IDENT -> {
                next()
                VarRef(t.text, t.line, t.col)
            }
            Tk.KW -> when (t.text) {
                "true" -> {
                    next()
                    BoolLit(true, t.line, t.col)
                }
                "false" -> {
                    next()
                    BoolLit(false, t.line, t.col)
                }
                "run" -> runCall()
                else -> fail("unexpected ${describe(t)} in expression")
            }
            Tk.OP -> when (t.text) {
                "(" -> {
                    next()
                    val e = expr()
                    expectOp(")")
                    e
                }
                "[" -> {
                    next()
                    val items = ArrayList<Expr>()
                    if (!isOp("]")) {
                        items.add(expr())
                        while (isOp(",")) {
                            next()
                            items.add(expr())
                        }
                    }
                    expectOp("]")
                    ListLit(items, t.line, t.col)
                }
                else -> fail("unexpected ${describe(t)} in expression")
            }
            else -> fail("expected a value but found ${describe(t)}")
        }
    }
}
