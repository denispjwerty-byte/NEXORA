package nx

internal class Env(private val parent: Env?, private val isFrame: Boolean = false) {
    private class Slot(var value: Any?, val fixed: Boolean)

    private val vars = HashMap<String, Slot>()

    private fun find(name: String): Slot? {
        var e: Env? = this
        while (e != null) {
            val s = e.vars[name]
            if (s != null) return s
            e = e.parent
        }
        return null
    }

    fun declare(name: String, value: Any?, fixed: Boolean, line: Int, col: Int) {
        if (vars.containsKey(name)) {
            throw NxException("NX3002", "'$name' is already declared in this scope", line, col)
        }
        // shadowing of outer names within the same action is an error
        var e: Env? = if (isFrame) null else parent
        while (e != null) {
            if (e.vars.containsKey(name)) {
                throw NxException("NX3003", "'$name' would shadow an outer variable", line, col)
            }
            e = if (e.isFrame) null else e.parent
        }
        vars[name] = Slot(value, fixed)
    }

    fun lookup(name: String, line: Int, col: Int): Any? {
        val s = find(name) ?: throw NxException("NX3001", "'$name' is not declared", line, col)
        return s.value
    }

    fun assign(name: String, value: Any?, line: Int, col: Int) {
        val s = find(name) ?: throw NxException("NX3001", "'$name' is not declared", line, col)
        if (s.fixed) throw NxException("NX3004", "cannot change fixed '$name'", line, col)
        s.value = value
    }
}

private class ReturnSignal(val value: Any?) : RuntimeException(null, null, false, false)

class NxInterpreter(
    private val out: (String) -> Unit,
    private val input: (String) -> String = { throw NxException("NX9020", "'ask' is not available in this host") },
    modules: Map<String, List<NativeFunction>> = emptyMap(),
    private val stepLimit: Int = 2_000_000
) {
    private val allModules: Map<String, List<NativeFunction>> = Stdlib.modules + modules
    private val global = Env(null, true)
    private val actions = HashMap<String, ActionDecl>()
    private val natives = HashMap<String, NativeFunction>()
    private var steps = 0
    private var depth = 0
    private var lastErrorText = ""

    init {
        for (f in Stdlib.core) natives[f.name] = f
        natives["lastError"] = NativeFunction("lastError", 0) { _ -> lastErrorText }
    }

    fun run(program: Program) {
        steps = 0
        depth = 0
        for (s in program.body) {
            if (s is ActionDecl) {
                if (actions.containsKey(s.name)) {
                    throw NxException("NX3002", "action '${s.name}' is already declared", s.line, s.col)
                }
                actions[s.name] = s
            }
        }
        execStmts(program.body, global)
    }

    fun hasAction(name: String): Boolean = actions.containsKey(name)

    fun actionArity(name: String): Int? = actions[name]?.params?.size

    /** Calls an action from the host (for example `update` every frame). Resets the step budget. */
    fun callAction(name: String, args: List<Any?>): Any? {
        steps = 0
        return invoke(name, args, 0, 0)
    }

    private fun tick(line: Int, col: Int) {
        steps++
        if (steps > stepLimit) {
            throw NxException("NX9010", "step limit exceeded (possible infinite loop)", line, col)
        }
    }

    private fun execStmts(list: List<Stmt>, env: Env) {
        for (s in list) exec(s, env)
    }

    private fun execBlock(list: List<Stmt>, parent: Env) {
        execStmts(list, Env(parent))
    }

    private fun exec(s: Stmt, env: Env) {
        tick(s.line, s.col)
        when (s) {
            is Say -> out(display(eval(s.value, env)))
            is DataDecl -> env.declare(s.name, eval(s.value, env), s.fixed, s.line, s.col)
            is Change -> assign(s, env)
            is Ask -> {
                val answer = try {
                    input(s.name)
                } catch (e: NxException) {
                    throw e.at(s.line, s.col)
                }
                env.assign(s.name, answer, s.line, s.col)
            }
            is Check -> {
                val c = eval(s.cond, env)
                if (c !is Boolean) {
                    throw NxException("NX4003", "'check' needs a Bool but got ${typeName(c)}", s.line, s.col)
                }
                if (c) {
                    execBlock(s.then, env)
                } else {
                    val o = s.otherwise
                    if (o != null) execBlock(o, env)
                }
            }
            is Repeat -> {
                val n = eval(s.count, env)
                if (n !is Long) {
                    throw NxException("NX4004", "'repeat' needs an Int but got ${typeName(n)}", s.line, s.col)
                }
                if (n < 0) throw NxException("NX9002", "repeat count must be >= 0", s.line, s.col)
                var i = 0L
                while (i < n) {
                    tick(s.line, s.col)
                    execBlock(s.body, env)
                    i++
                }
            }
            is RepeatWhile -> {
                while (true) {
                    tick(s.line, s.col)
                    val c = eval(s.cond, env)
                    if (c !is Boolean) {
                        throw NxException("NX4003", "'repeat while' needs a Bool but got ${typeName(c)}", s.line, s.col)
                    }
                    if (!c) break
                    execBlock(s.body, env)
                }
            }
            is ActionDecl -> {} // registered before execution
            is RunStmt -> evalRun(s.call, env)
            is Yield -> {
                if (depth == 0) throw NxException("NX3007", "'yield' can only be used inside an action", s.line, s.col)
                val v = s.value
                throw ReturnSignal(if (v == null) null else eval(v, env))
            }
            is Load -> {
                val fns = allModules[s.module]
                    ?: throw NxException("NX3005", "unknown module '${s.module}'", s.line, s.col)
                for (f in fns) natives[f.name] = f
            }
            is Attempt -> {
                try {
                    execBlock(s.body, env)
                } catch (e: NxException) {
                    if (!e.code.startsWith("NX9") || e.code == "NX9010") throw e
                    lastErrorText = e.message
                    execBlock(s.recover, env)
                }
            }
        }
    }

    private fun assign(s: Change, env: Env) {
        val value = eval(s.value, env)
        when (val t = s.target) {
            is VarRef -> env.assign(t.name, value, s.line, s.col)
            is Index -> {
                val list = asMutableList(eval(t.target, env))
                    ?: throw NxException("NX4006", "only List elements can be changed", s.line, s.col)
                val idx = eval(t.index, env)
                if (idx !is Long) {
                    throw NxException("NX4005", "index must be Int but got ${typeName(idx)}", s.line, s.col)
                }
                if (idx < 0 || idx >= list.size) {
                    throw NxException("NX9003", "index $idx is out of range", s.line, s.col)
                }
                list[idx.toInt()] = value
            }
            else -> throw NxException("NX2003", "'change' needs a variable or a list element", s.line, s.col)
        }
    }

    private fun evalRun(call: RunCall, env: Env): Any? {
        tick(call.line, call.col)
        val args = ArrayList<Any?>()
        for (a in call.args) args.add(eval(a, env))
        return invoke(call.name, args, call.line, call.col)
    }

    private fun invoke(name: String, args: List<Any?>, line: Int, col: Int): Any? {
        val a = actions[name]
        if (a != null) {
            if (args.size != a.params.size) {
                throw NxException(
                    "NX9004",
                    "action '$name' expects ${a.params.size} argument(s) but got ${args.size}",
                    line, col
                )
            }
            if (depth >= 200) throw NxException("NX9005", "call depth limit exceeded", line, col)
            val env = Env(global, true)
            for (i in a.params.indices) env.declare(a.params[i], args[i], false, a.line, a.col)
            depth++
            try {
                execStmts(a.body, env)
            } catch (r: ReturnSignal) {
                return r.value
            } finally {
                depth--
            }
            return null
        }
        val n = natives[name]
            ?: throw NxException("NX3006", "unknown action '$name' (did you forget 'load'?)", line, col)
        if (n.arity >= 0 && n.arity != args.size) {
            throw NxException("NX9004", "'$name' expects ${n.arity} argument(s) but got ${args.size}", line, col)
        }
        try {
            return n.fn(args)
        } catch (e: NxException) {
            throw e.at(line, col)
        }
    }

    // ---------------- expressions ----------------

    private fun eval(e: Expr, env: Env): Any? = when (e) {
        is IntLit -> e.v
        is FloatLit -> e.v
        is TextLit -> e.v
        is BoolLit -> e.v
        is ListLit -> {
            val l = ArrayList<Any?>()
            for (item in e.items) l.add(eval(item, env))
            l
        }
        is VarRef -> env.lookup(e.name, e.line, e.col)
        is Index -> indexValue(e, env)
        is Unary -> unary(e, env)
        is Binary -> binary(e, env)
        is RunCall -> evalRun(e, env)
    }

    private fun indexValue(e: Index, env: Env): Any? {
        val target = eval(e.target, env)
        val idx = eval(e.index, env)
        if (idx !is Long) {
            throw NxException("NX4005", "index must be Int but got ${typeName(idx)}", e.line, e.col)
        }
        return when (target) {
            is List<*> -> {
                if (idx < 0 || idx >= target.size) {
                    throw NxException("NX9003", "index $idx is out of range", e.line, e.col)
                }
                target[idx.toInt()]
            }
            is String -> {
                if (idx < 0 || idx >= target.length) {
                    throw NxException("NX9003", "index $idx is out of range", e.line, e.col)
                }
                target[idx.toInt()].toString()
            }
            else -> throw NxException("NX4006", "cannot index ${typeName(target)}", e.line, e.col)
        }
    }

    private fun unary(e: Unary, env: Env): Any? {
        val v = eval(e.operand, env)
        return when (e.op) {
            "-" -> when (v) {
                is Long -> -v
                is Double -> -v
                else -> throw NxException("NX4002", "cannot negate ${typeName(v)}", e.line, e.col)
            }
            else -> {
                if (v !is Boolean) {
                    throw NxException("NX4002", "'not' needs a Bool but got ${typeName(v)}", e.line, e.col)
                }
                !v
            }
        }
    }

    private fun binary(e: Binary, env: Env): Any? {
        if (e.op == "and" || e.op == "or") {
            val l = eval(e.left, env)
            if (l !is Boolean) {
                throw NxException("NX4001", "'${e.op}' needs Bool operands but got ${typeName(l)}", e.line, e.col)
            }
            if (e.op == "and" && !l) return false
            if (e.op == "or" && l) return true
            val r = eval(e.right, env)
            if (r !is Boolean) {
                throw NxException("NX4001", "'${e.op}' needs Bool operands but got ${typeName(r)}", e.line, e.col)
            }
            return r
        }
        val l = eval(e.left, env)
        val r = eval(e.right, env)
        return when (e.op) {
            "==" -> valuesEqual(l, r)
            "!=" -> !valuesEqual(l, r)
            "+" -> if (l is String && r is String) l + r else arith(e.op, l, r, e)
            else -> arith(e.op, l, r, e)
        }
    }

    private fun valuesEqual(a: Any?, b: Any?): Boolean {
        if (a is Long && b is Long) return a == b
        if ((a is Long || a is Double) && (b is Long || b is Double)) {
            return (a as Number).toDouble() == (b as Number).toDouble()
        }
        return a == b
    }

    private fun divZero(e: Binary): NxException = NxException("NX9001", "division by zero", e.line, e.col)

    private fun arith(op: String, l: Any?, r: Any?, e: Binary): Any? {
        if (l is Long && r is Long) {
            return when (op) {
                "+" -> l + r
                "-" -> l - r
                "*" -> l * r
                "/" -> {
                    if (r == 0L) throw divZero(e)
                    l / r
                }
                "%" -> {
                    if (r == 0L) throw divZero(e)
                    l % r
                }
                "<" -> l < r
                "<=" -> l <= r
                ">" -> l > r
                ">=" -> l >= r
                else -> throw NxException("NX4001", "unknown operator '$op'", e.line, e.col)
            }
        }
        if ((l is Long || l is Double) && (r is Long || r is Double)) {
            val a = (l as Number).toDouble()
            val b = (r as Number).toDouble()
            return when (op) {
                "+" -> a + b
                "-" -> a - b
                "*" -> a * b
                "/" -> {
                    if (b == 0.0) throw divZero(e)
                    a / b
                }
                "%" -> {
                    if (b == 0.0) throw divZero(e)
                    a % b
                }
                "<" -> a < b
                "<=" -> a <= b
                ">" -> a > b
                ">=" -> a >= b
                else -> throw NxException("NX4001", "unknown operator '$op'", e.line, e.col)
            }
        }
        throw NxException(
            "NX4001",
            "operator '$op' cannot be applied to ${typeName(l)} and ${typeName(r)}",
            e.line, e.col
        )
    }
}
