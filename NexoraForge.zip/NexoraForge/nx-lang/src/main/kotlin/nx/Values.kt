package nx

/** A function implemented by the host (stdlib or an engine module). Arity -1 means variadic. */
class NativeFunction(val name: String, val arity: Int, val fn: (List<Any?>) -> Any?)

fun typeName(v: Any?): String = when (v) {
    null -> "Void"
    is Long -> "Int"
    is Double -> "Float"
    is Boolean -> "Bool"
    is String -> "Text"
    is List<*> -> "List"
    else -> "Any"
}

fun display(v: Any?): String = when (v) {
    null -> "void"
    is String -> v
    is List<*> -> v.joinToString(", ", "[", "]") { if (it is String) "\"$it\"" else display(it) }
    else -> v.toString()
}

@Suppress("UNCHECKED_CAST")
fun asMutableList(v: Any?): ArrayList<Any?>? = v as? ArrayList<Any?>
