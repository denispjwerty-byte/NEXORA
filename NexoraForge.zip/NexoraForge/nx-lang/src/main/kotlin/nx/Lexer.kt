package nx

enum class Tk { INT, FLOAT, TEXT, IDENT, KW, OP, NEWLINE, INDENT, DEDENT, EOF }

data class Token(val type: Tk, val text: String, val line: Int, val col: Int)

object Lexer {
    val keywords: Set<String> = setOf(
        "say", "data", "fixed", "change", "ask", "check", "otherwise", "repeat", "while",
        "action", "run", "yield", "load", "build", "attempt", "recover",
        "and", "or", "not", "true", "false"
    )

    private fun isLetter(c: Char): Boolean = c in 'a'..'z' || c in 'A'..'Z' || c == '_'
    private fun isDigit(c: Char): Boolean = c in '0'..'9'

    fun tokenize(source: String): List<Token> {
        val out = ArrayList<Token>()
        val indents = ArrayList<Int>()
        indents.add(0)
        val lines = source.replace("\r\n", "\n").replace('\r', '\n').split("\n")

        for ((idx, raw) in lines.withIndex()) {
            val ln = idx + 1
            val first = raw.indexOfFirst { it != ' ' && it != '\t' }
            if (first == -1 || raw[first] == '#') continue
            for (k in 0 until first) {
                if (raw[k] == '\t') {
                    throw NxException("NX2001", "tabs are not allowed in indentation; use 4 spaces", ln, k + 1)
                }
            }

            if (first > indents[indents.size - 1]) {
                indents.add(first)
                out.add(Token(Tk.INDENT, "", ln, 1))
            } else if (first < indents[indents.size - 1]) {
                while (first < indents[indents.size - 1]) {
                    indents.removeAt(indents.size - 1)
                    out.add(Token(Tk.DEDENT, "", ln, 1))
                }
                if (first != indents[indents.size - 1]) {
                    throw NxException("NX2002", "inconsistent indentation", ln, 1)
                }
            }

            var i = first
            while (i < raw.length) {
                val c = raw[i]
                val col = i + 1
                if (c == ' ' || c == '\t') {
                    i++
                    continue
                }
                if (c == '#') break

                if (isDigit(c)) {
                    val s = i
                    while (i < raw.length && isDigit(raw[i])) i++
                    var isFloat = false
                    if (i + 1 < raw.length && raw[i] == '.' && isDigit(raw[i + 1])) {
                        isFloat = true
                        i++
                        while (i < raw.length && isDigit(raw[i])) i++
                    }
                    val text = raw.substring(s, i)
                    if (!isFloat && text.toLongOrNull() == null) {
                        throw NxException("NX1004", "integer literal is too large", ln, col)
                    }
                    out.add(Token(if (isFloat) Tk.FLOAT else Tk.INT, text, ln, col))
                    continue
                }

                if (c == '"') {
                    val sb = StringBuilder()
                    i++
                    var closed = false
                    while (i < raw.length) {
                        val d = raw[i]
                        if (d == '"') {
                            closed = true
                            i++
                            break
                        }
                        if (d == '\\') {
                            if (i + 1 >= raw.length) break
                            val e = raw[i + 1]
                            when (e) {
                                'n' -> sb.append('\n')
                                't' -> sb.append('\t')
                                '"' -> sb.append('"')
                                '\\' -> sb.append('\\')
                                else -> throw NxException("NX1003", "unknown escape sequence", ln, i + 1)
                            }
                            i += 2
                        } else {
                            sb.append(d)
                            i++
                        }
                    }
                    if (!closed) throw NxException("NX1002", "unterminated text literal", ln, col)
                    out.add(Token(Tk.TEXT, sb.toString(), ln, col))
                    continue
                }

                if (c == '@') {
                    val s = i
                    i++
                    while (i < raw.length && isLetter(raw[i])) i++
                    val text = raw.substring(s, i)
                    if (text != "@start" && text != "@stop") {
                        throw NxException("NX1001", "unknown directive '$text'", ln, col)
                    }
                    out.add(Token(Tk.KW, text, ln, col))
                    continue
                }

                if (isLetter(c)) {
                    val s = i
                    while (i < raw.length && (isLetter(raw[i]) || isDigit(raw[i]))) i++
                    val text = raw.substring(s, i)
                    out.add(Token(if (text in keywords) Tk.KW else Tk.IDENT, text, ln, col))
                    continue
                }

                val two = if (i + 1 < raw.length) raw.substring(i, i + 2) else ""
                if (two == "==" || two == "!=" || two == "<=" || two == ">=") {
                    out.add(Token(Tk.OP, two, ln, col))
                    i += 2
                    continue
                }
                if (c in "<>+-*/%=()[],") {
                    out.add(Token(Tk.OP, c.toString(), ln, col))
                    i++
                    continue
                }
                throw NxException("NX1001", "unexpected character '$c'", ln, col)
            }
            out.add(Token(Tk.NEWLINE, "", ln, raw.length + 1))
        }

        while (indents.size > 1) {
            indents.removeAt(indents.size - 1)
            out.add(Token(Tk.DEDENT, "", lines.size, 1))
        }
        out.add(Token(Tk.EOF, "", lines.size, 1))
        return out
    }
}
