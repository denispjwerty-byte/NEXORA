package nx

/** All NX errors. Codes: NX1xxx lexical, NX2xxx syntax, NX3xxx semantic, NX4xxx types, NX9xxx runtime. */
class NxException(
    val code: String,
    val detail: String,
    val line: Int = 0,
    val col: Int = 0
) : RuntimeException() {
    override val message: String
        get() = "$code: $detail" + (if (line > 0) " (line $line:$col)" else "")

    /** Adds a source position if the error has none yet. */
    fun at(l: Int, c: Int): NxException = if (line > 0) this else NxException(code, detail, l, c)
}
