package nx

object Stdlib {
    fun num(v: Any?, fn: String): Double = when (v) {
        is Long -> v.toDouble()
        is Double -> v
        else -> throw NxException("NX4008", "$fn expects a number but got ${typeName(v)}")
    }

    /** Always available. */
    val core: List<NativeFunction> = listOf(
        NativeFunction("length", 1) { a ->
            when (val v = a[0]) {
                is List<*> -> v.size.toLong()
                is String -> v.length.toLong()
                else -> throw NxException("NX4008", "length expects a List or Text but got ${typeName(v)}")
            }
        },
        NativeFunction("push", 2) { a ->
            val l = asMutableList(a[0])
                ?: throw NxException("NX4008", "push expects a List but got ${typeName(a[0])}")
            l.add(a[1])
            null
        },
        NativeFunction("toText", 1) { a -> display(a[0]) },
        NativeFunction("toInt", 1) { a ->
            when (val v = a[0]) {
                is Long -> v
                is Double -> {
                    if (v.isNaN() || v.isInfinite()) throw NxException("NX9006", "cannot convert $v to Int")
                    v.toLong()
                }
                is String -> v.trim().toLongOrNull()
                    ?: throw NxException("NX9006", "cannot convert \"$v\" to Int")
                else -> throw NxException("NX4008", "toInt expects Int, Float or Text but got ${typeName(v)}")
            }
        },
        NativeFunction("toFloat", 1) { a ->
            when (val v = a[0]) {
                is Long -> v.toDouble()
                is Double -> v
                is String -> v.trim().toDoubleOrNull()
                    ?: throw NxException("NX9006", "cannot convert \"$v\" to Float")
                else -> throw NxException("NX4008", "toFloat expects Int, Float or Text but got ${typeName(v)}")
            }
        }
    )

    /** `load math` */
    val math: List<NativeFunction> = listOf(
        NativeFunction("sqrt", 1) { a ->
            val x = num(a[0], "sqrt")
            if (x < 0.0) throw NxException("NX9007", "sqrt of a negative number")
            Math.sqrt(x)
        },
        NativeFunction("sin", 1) { a -> Math.sin(num(a[0], "sin")) },
        NativeFunction("cos", 1) { a -> Math.cos(num(a[0], "cos")) },
        NativeFunction("abs", 1) { a ->
            when (val v = a[0]) {
                is Long -> Math.abs(v)
                is Double -> Math.abs(v)
                else -> throw NxException("NX4008", "abs expects a number but got ${typeName(v)}")
            }
        },
        NativeFunction("floor", 1) { a -> Math.floor(num(a[0], "floor")).toLong() },
        NativeFunction("min", 2) { a ->
            val x = a[0]
            val y = a[1]
            if (x is Long && y is Long) minOf(x, y) else minOf(num(x, "min"), num(y, "min"))
        },
        NativeFunction("max", 2) { a ->
            val x = a[0]
            val y = a[1]
            if (x is Long && y is Long) maxOf(x, y) else maxOf(num(x, "max"), num(y, "max"))
        },
        NativeFunction("toRadians", 1) { a -> Math.toRadians(num(a[0], "toRadians")) },
        NativeFunction("pi", 0) { _ -> Math.PI },
        NativeFunction("random", 0) { _ -> Math.random() }
    )

    val modules: Map<String, List<NativeFunction>> = mapOf("math" to math)
}
